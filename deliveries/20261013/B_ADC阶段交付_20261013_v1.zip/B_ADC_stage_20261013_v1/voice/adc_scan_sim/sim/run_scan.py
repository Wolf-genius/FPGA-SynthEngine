"""Fresh timestamped evidence, explicit staged Icarus compiler, checked exits."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from check_scan import verify

sys.stdout.reconfigure(encoding="utf-8")
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument("--iverilog",default="D:/iverilog/bin/iverilog.exe")
p.add_argument("--vvp",default="D:/iverilog/bin/vvp.exe")
p.add_argument("--out",default=f"sim/verified_{datetime.now():%Y%m%d_%H%M%S}")
args=p.parse_args()
out=(root/args.out).resolve()
assert out.is_relative_to(root/"sim")
out.mkdir(parents=True,exist_ok=False)
shared=root.parent/"adc_spi_sim"
jobs={"integrated":("tb_adc_scan",[shared/"src/adc_spi.v",root/"src/adc_scan_controller.v",root/"src/adc_scan.v",shared/"tb/mcp3208_model.sv",root/"tb/tb_adc_scan.sv"]),
      "faults":("tb_scan_faults",[root/"src/adc_scan_controller.v",root/"tb/tb_scan_faults.sv"])}
inputs=sorted(set([x for _,ss in jobs.values() for x in ss]+[Path(__file__).resolve(),root/"sim/check_scan.py"]))
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
hashes=lambda:{os.path.relpath(x,root):sha(x) for x in inputs}
m={"status":"INCOMPLETE","started_at":datetime.now(timezone.utc).isoformat(),"input_sha256":hashes(),"steps":[],
   "scope":"Eight raw 12-bit channels only; no pressure mapping, Gowin, board or delivery package",
   "compile_method":"Installed Icarus 12 devel: iverilog -E then ivl.exe; known outer-driver 0xC0000005 workaround"}
env=os.environ.copy(); env.pop("IVERILOG_ICONFIG",None)


def save(): (out/"manifest.json").write_text(json.dumps(m,indent=2)+"\n",encoding="utf-8")


def run(label,argv,cwd,logdir):
    r=subprocess.run([str(a) for a in argv],cwd=cwd,env=env,capture_output=True,text=True,errors="replace",timeout=60)
    log=logdir/f"{label}.log"
    log.write_text(f"cwd={cwd}\nargv={json.dumps([str(a) for a in argv])}\nexit_code={r.returncode}\nSTDOUT:\n{r.stdout}\nSTDERR:\n{r.stderr}",encoding="utf-8")
    m["steps"].append({"step":label,"argv":[str(a) for a in argv],"cwd":str(cwd),"exit_code":r.returncode,"log":str(log.relative_to(out))})
    save(); print(f"{log.parent.name}/{label}: exit={r.returncode}")
    if r.returncode: raise RuntimeError(f"Failed: {log}")
    return r


try:
    run("iverilog_version",[args.iverilog,"-V"],root,out)
    run("vvp_version",[args.vvp,"-V"],root,out)
    ivl=Path(args.iverilog).resolve().parents[1]/"lib/ivl"
    for name,(top,sources) in jobs.items():
        d=out/name; d.mkdir()
        pre=d/"preprocessed.sv"; exe=d/"checked.vvp"; cfg=d/"compile.conf"
        run("01_preprocess",[args.iverilog,"-g2012","-E","-o",pre,*sources],root,d)
        assert not pre.read_text(encoding="utf-8").startswith("#!")
        cfg.write_text("\n".join([f"root:{top}",f"basedir:{ivl}",
            *[f"module:{ivl/(mod+'.vpi')}" for mod in ("system","vhdl_sys","vhdl_textio","v2005_math","va_math","v2009")],
            "generation:2012","generation:no-specify","generation:assertions","generation:xtypes",
            "generation:io-range-error","generation:icarus-misc","warnings:nidRpsta",
            "ignore_missing_modules:false",f"out:{exe}","iwidth:32","widthcap:65536"])+"\n",encoding="utf-8")
        assert not exe.exists()
        run("02_compile",[ivl/"ivl.exe","-C",cfg,"-C",ivl/"vvp.conf","--",pre],root,d)
        assert exe.exists()
        r=run("03_simulation",[args.vvp,exe],d,d)
        marker="PASS ALL integrated frames=6 rounds=7 transactions=53 aborted=1 atomic_CH4=7 timeout_count=0" if name=="integrated" else "PASS ALL faults rounds=7 published=4 timeouts=3 recovery=3"
        assert marker in r.stdout, f"Missing completion marker: {name}"
    m["waveform_assertions"]=verify(out)
    assert m["input_sha256"]==hashes(), "Source changed during run"
    m["status"]="PASS"; m["completed_at"]=datetime.now(timezone.utc).isoformat()
    m["output_sha256"]={str(x.relative_to(out)):sha(x) for x in out.rglob("*") if x.is_file() and x.name!="manifest.json"}
    save(); print(f"PASS evidence={out}")
except Exception as e:
    m["status"]="FAILED"; m["failure"]=str(e); save(); raise
