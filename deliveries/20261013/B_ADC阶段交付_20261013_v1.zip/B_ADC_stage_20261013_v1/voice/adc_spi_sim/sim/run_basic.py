"""Compile current sources afresh; retain commands, exits, hashes and waveforms."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

from check_waveform import verify

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--iverilog", default="D:/iverilog/bin/iverilog.exe")
parser.add_argument("--vvp", default="D:/iverilog/bin/vvp.exe")
parser.add_argument("--out", default=f"sim/verified_{datetime.now():%Y%m%d_%H%M%S}")
args = parser.parse_args()
out = (ROOT / args.out).resolve()
if not out.is_relative_to(ROOT / "sim"):
    raise SystemExit("Evidence output must be inside this project's sim directory")
out.mkdir(parents=True, exist_ok=False) # Never reuse a prior executable/evidence set.
sources = [ROOT/"src/adc_spi.v", ROOT/"tb/mcp3208_model.sv", ROOT/"tb/tb_adc_spi.sv"]
inputs = sources + [Path(__file__).resolve(), ROOT/"sim/check_waveform.py"]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {"started_at":datetime.now(timezone.utc).isoformat(), "cwd":str(ROOT),
            "status":"INCOMPLETE", "steps":[],
            "input_sha256":{str(p.relative_to(ROOT)):sha(p) for p in inputs},
            "scope":"MCP3208 single-transaction RTL simulation only; no synthesis or board test"}
env = os.environ.copy()
env.pop("IVERILOG_ICONFIG", None) # Prevent a stale config from redirecting output.


def save_manifest():
    (out/"manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")


def run(label, argv, cwd=ROOT, required=True):
    result = subprocess.run([str(a) for a in argv], cwd=cwd, env=env,
                            capture_output=True, text=True, errors="replace", timeout=60)
    log = out/f"{label}.log"
    log.write_text(f"cwd={cwd}\nargv={json.dumps([str(a) for a in argv])}\n"
                   f"exit_code={result.returncode}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}", encoding="utf-8")
    manifest["steps"].append({"name":label, "argv":[str(a) for a in argv],
                              "cwd":str(cwd), "exit_code":result.returncode, "log":log.name})
    save_manifest()
    print(f"{label}: exit={result.returncode}")
    if required and result.returncode:
        raise RuntimeError(f"{label} failed; see {log}")
    return result


try:
    run("01_iverilog_version", [args.iverilog,"-V"])
    run("02_vvp_version", [args.vvp,"-V"])
    standard = out/"driver_probe.vvp"
    probe = run("03_driver_probe", [args.iverilog,"-g2012","-Wall","-s","tb_adc_spi",
                                   "-o",standard,*sources], required=False)
    executable = out/"tb_adc_spi.checked.vvp"
    if probe.returncode == 0:
        executable = standard
        manifest["compile_method"] = "iverilog driver"
    else:
        # This installed Windows devel driver crashes after code generation.
        # Its output is never executed. Invoke the SAME compiler's preprocessor
        # and elaborator/code generator separately, checking BOTH exit codes.
        preprocessed = out/"preprocessed.sv"
        run("04_preprocess", [args.iverilog,"-g2012","-E","-o",preprocessed,*sources])
        assert not preprocessed.read_text(encoding="utf-8").startswith("#!"), "Not Verilog input"
        ivl_dir = Path(args.iverilog).resolve().parents[1]/"lib/ivl"
        modules = ("system","vhdl_sys","vhdl_textio","v2005_math","va_math","v2009")
        config = out/"checked_compile.conf"
        config.write_text("\n".join([
            "root:tb_adc_spi", f"basedir:{ivl_dir}",
            *[f"module:{ivl_dir/(m+'.vpi')}" for m in modules],
            "generation:2012", "generation:no-specify", "generation:assertions",
            "generation:xtypes", "generation:io-range-error", "generation:icarus-misc",
            "warnings:nidRpsta", "ignore_missing_modules:false", f"out:{executable}",
            "iwidth:32", "widthcap:65536"])+"\n", encoding="utf-8")
        assert not executable.exists(), "Compiler output must be new"
        run("05_compile", [ivl_dir/"ivl.exe","-C",config,"-C",ivl_dir/"vvp.conf","--",preprocessed])
        manifest["compile_method"] = "iverilog -E then ivl.exe; driver probe failed and was NOT executed"
        manifest["tool_issue"] = {"driver_exit_code":probe.returncode,
                                  "note":"Installed Windows Icarus 12 devel driver abnormal exit; separate current-source stages used"}
    assert executable.is_file() and executable.stat().st_size > 0
    manifest["executed_vvp"] = executable.name
    manifest["compiled_vvp_sha256"] = sha(executable)
    sim = run("06_simulation", [args.vvp,executable], cwd=out)
    assert "PASS ALL normal_published=31 reset_aborted_spi=5 reset_gap_canceled=1" in sim.stdout
    report = verify(out)
    manifest["waveform_assertions"] = {k:v for k,v in report.items() if k not in ("frames","valid_pulses")}
    assert manifest["input_sha256"] == {str(p.relative_to(ROOT)):sha(p) for p in inputs}, "Source changed during verification"
    manifest["status"] = "PASS"
    manifest["completed_at"] = datetime.now(timezone.utc).isoformat()
    manifest["output_sha256"] = {str(p.relative_to(out)):sha(p) for p in out.iterdir()
                                if p.is_file() and p.name != "manifest.json"}
    save_manifest()
    print(f"PASS evidence={out}")
except Exception as exc:
    manifest["status"] = "FAILED"
    manifest["failure"] = str(exc)
    save_manifest()
    raise
