`timescale 1ns/1ps
module tb_core;
 parameter integer PERIOD=50000;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0; reg [95:0] values=0;
 wire miso,cs_n,sclk,mosi,start,busy,valid,missed,ready;
 wire [11:0] data,snapshot,selected; wire [7:0] led;
 wire [2:0] channel; wire [23:0] command_seen; wire integer rises,start_edge;
 adc_min_core #(.SAMPLE_CYCLES(PERIOD),.PAGE_CYCLES(60000)) dut(
  clk,rst_n,miso,cs_n,sclk,mosi,start,busy,data,valid,missed,led,snapshot,ready);
 mcp3208_model model(rst_n,cs_n,sclk,mosi,values,200,miso,channel,selected,command_seen,rises,start_edge);
 integer cycles=0,requests=0,results=0,skips=0,completed=0,aborted=0;
 integer n=0,falls=0; reg [23:0] command; reg [11:0] payload,expected,previous_data=0;
 reg previous_valid=0; time last_edge=0,cs_begin=0,last_cs=0,request_time=0;
 integer fd;
 function [11:0] pattern(input integer k);
  case(k%6) 0:pattern=0;1:pattern=1;2:pattern=12'habc;3:pattern=4095;4:pattern=12'h555;5:pattern=12'haaa;endcase
 endfunction
 always @(negedge cs_n) begin
  n=0; falls=0; command=0; payload=0; cs_begin=$time; last_edge=$time;
  expected=values[11:0];
  if(last_cs && $time-last_cs<2000) $fatal(1,"CS gap");
 end
 always @(posedge sclk) if(rst_n) begin
  if(cs_n || $time-last_edge!=1000) $fatal(1,"SPI edge/setup");
  last_edge=$time; n=n+1; command={command[22:0],mosi};
  if(n<=11 && miso!==1'bx) $fatal(1,"Prefix");
  if(n==12 && miso!==0) $fatal(1,"Null");
  if(n>=13) payload={payload[10:0],miso};
 end
 always @(negedge sclk) if(rst_n && !cs_n) begin
  if($time-last_edge!=1000) $fatal(1,"Half period"); last_edge=$time; falls=falls+1;
 end
 always @(posedge cs_n) if(cs_begin) begin
  last_cs=$time;
  if(rst_n) begin
   if(n!=24 || falls!=24 || command!==24'h060000 || payload!==expected || $time-last_edge!=1000) $fatal(1,"Protocol/payload");
   completed=completed+1;
  end else aborted=aborted+1;
  cs_begin=0;
 end
 always @(posedge clk) begin
  if(!rst_n) cycles=0; else cycles=cycles+1;
  #1;
  if(!rst_n) begin previous_valid=0; previous_data=0; end
  else begin
   if(start) begin
    if(cycles%PERIOD!=0 || busy) $fatal(1,"Request grid/busy");
    requests=requests+1; request_time=$time-1;
   end
   if(missed) begin if(cycles%PERIOD!=0 || start) $fatal(1,"Skipped tick"); skips=skips+1; end
   if(valid) begin
    if(previous_valid || data!==expected || !cs_n || busy || completed!=results+1) $fatal(1,"Publish");
    results=results+1;
    $fdisplay(fd,"%0d,%0d,%03h,%0d",results,$time-1,data,$time-1-request_time);
    $display("PASS capture=%0d code=%h latency_ns=%0d",results,data,$time-1-request_time);
   end else if(data!==previous_data) $fatal(1,"Data changed without valid");
   previous_data=data; previous_valid=valid;
  end
 end
 initial begin
  $dumpfile("core.vcd"); $dumpvars(0,rst_n,values,miso,cs_n,sclk,mosi,start,busy,data,valid,missed,led,snapshot,ready);
  fd=$fopen("captures.csv","w"); $fdisplay(fd,"index,time_ns,code,latency_ns");
  #100; rst_n=1;
  for(integer k=0;k<6;k=k+1) begin
   @(negedge clk); values[11:0]=pattern(k);
   @(posedge valid); @(negedge clk);
  end
  // Cancel a transaction in the receive window; next periodic request recovers.
  @(negedge cs_n); repeat(15) @(posedge sclk); #17; rst_n=0; #1;
  if(data!==0 || valid!==0 || led!==0 || cs_n!==1 || sclk!==0) $fatal(1,"Reset cancellation");
  #22; rst_n=1; values[11:0]=12'h789;
  @(posedge valid); @(negedge clk);
  if(results!=7 || aborted!=1 || requests!=8) $fatal(1,"Counts");
  if(PERIOD==50000 && skips!=0) $fatal(1,"Unexpected normal skip");
  if(PERIOD==1000 && skips<12) $fatal(1,"Missing busy skips");
  $display("PASS ALL core period=%0d results=%0d aborted=%0d requests=%0d skipped=%0d",PERIOD,results,aborted,requests,skips);
  $fclose(fd); $finish;
 end
 initial begin #10000000; $fatal(1,"Timeout"); end
endmodule
module tb_busy;
 tb_core #(.PERIOD(1000)) test();
endmodule
