`timescale 1ns/1ps
module tb_default_page;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,valid=0; reg [11:0] data=12'habc;
 wire [7:0] led; wire [11:0] snapshot; wire ready;
 time t0,t1;
 adc_led_pages dut(clk,rst_n,data,valid,led,snapshot,ready);
 initial begin
  $dumpfile("default_page.vcd"); $dumpvars(0,rst_n,valid,data,led,snapshot,ready);
  #25; rst_n=1; @(negedge clk); valid=1;
  @(posedge ready); t0=$time;
  @(negedge clk); data=12'h555;
  @(negedge clk); valid=0;
  @(posedge led[6]); t1=$time; #1;
  if(t1-t0!=1000000000 || snapshot!==12'habc || led[5:0]!==6'h2a) $fatal(1,"Default high");
  $display("PASS default_low_page_ns=%0d snapshot=%h",t1-t0,snapshot);
  @(negedge led[6]); #1;
  if($time-1-t1!=1000000000 || snapshot!==12'h555) $fatal(1,"Default low");
  $display("PASS ALL default_page two_pages_ns=2000000000 new_snapshot=%h",snapshot); $finish;
 end
 initial begin #2100000000; $fatal(1,"Timeout"); end
endmodule
