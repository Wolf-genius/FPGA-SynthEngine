`timescale 1ns/1ps
module tb_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0; wire miso,cs_n,sclk,mosi,cs2,sc2,mo2;
 wire [7:0] led,led2; reg [95:0] values=96'habc;
 wire [2:0] ch; wire [11:0] val; wire [23:0] cmd; wire integer rises,se;
 integer cycles=0,starts=0; time previous_start=0;
 adc_min_top #(.PAGE_CYCLES(5000)) dut(clk,rst_n,miso,cs_n,sclk,mosi,led);
 adc_min_top #(.PAGE_CYCLES(5000),.LED_INVERT_MASK(8'hff)) inverted(clk,rst_n,miso,cs2,sc2,mo2,led2);
 mcp3208_model model(rst_n,cs_n,sclk,mosi,values,200,miso,ch,val,cmd,rises,se);
 always @(posedge clk) begin
  if(!rst_n) cycles=0; else cycles=cycles+1;
  #1;
  if(led2!==~led || {cs2,sc2,mo2}!=={cs_n,sclk,mosi}) $fatal(1,"Polarity or wrapper mismatch");
 end
 always @(negedge cs_n) begin
  if(starts==0 && cycles!=50003) $fatal(1,"Reset release/first request: %0d",cycles);
  if(previous_start && $time-previous_start!=1000000) $fatal(1,"Top period");
  starts=starts+1; previous_start=$time;
 end
 initial begin
  $dumpfile("top.vcd"); $dumpvars(0,rst_n,cs_n,sclk,mosi,miso,led,led2);
  #107; rst_n=1;
  wait(led[7]); #1; if(led[6:0]!==7'h3c) $fatal(1,"Initial ABC low");
  @(posedge led[6]); #1; if(led[5:0]!==6'h2a) $fatal(1,"ABC high");
  @(negedge cs_n); repeat(14) @(posedge sclk); #17; rst_n=0;
  #1; if(led!==0 || led2!==8'hff || cs_n!==1 || sclk!==0) $fatal(1,"Async reset");
  starts=0; previous_start=0; cycles=0; #1; rst_n=1;
  wait(led[7]); #1; if(led[6:0]!==7'h3c) $fatal(1,"Recovery");
  $display("PASS ALL top default_1ms reset_release_2clks polarity_masks=00,FF short_reset_ns=2 recovery=ABC"); $finish;
 end
 initial begin #5000000; $fatal(1,"Timeout"); end
endmodule
