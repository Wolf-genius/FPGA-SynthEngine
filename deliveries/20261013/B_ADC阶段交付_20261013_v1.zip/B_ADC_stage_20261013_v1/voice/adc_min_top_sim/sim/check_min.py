"""Independent external VCD checks; no internal DUT state or generated executables."""
import csv,json,re
from pathlib import Path

def epochs(path):
    names={}; state={}; changes={}; t=0
    with path.open() as f:
        header=''
        for line in f:
            header+=line
            if line.startswith('$var '):
                p=line.split(); names[p[3]]=p[4]
            if '$enddefinitions' in line: break
        m=re.search(r'\$timescale\s+(\d+)\s*(ps|ns)\s+\$end',header)
        assert m
        scale=int(m[1])*(.001 if m[2]=='ps' else 1)
        for line in f:
            line=line.strip()
            if line.startswith('#'):
                old=state.copy(); state.update(changes)
                yield round(t*scale,3),old,state.copy()
                t=int(line[1:]); changes={}
            elif line.startswith('b'):
                v,k=line[1:].split(); changes[names[k]]=v
            elif line and line[0] in '01xz': changes[names[line[1:]]]=line[0]
        old=state.copy(); state.update(changes); yield round(t*scale,3),old,state.copy()

def verify(folder):
    report={}
    for name,period in [('normal',1000000),('busy',60000)]:
        last=None; pulse=None; publications=[]; widths=[]; requests=0
        for t,o,s in epochs(folder/name/'core.vcd'):
            if s.get('rst_n')!='1': last=None; pulse=None; continue
            if o.get('start')=='0' and s.get('start')=='1':
                if last is not None: assert t-last==period,(name,t-last)
                last=t; requests+=1
            if o.get('valid')=='0' and s.get('valid')=='1':
                pulse=t; publications.append((t,int(s['data'],2)))
            if o.get('valid')=='1' and s.get('valid')=='0':
                assert t-pulse==20; widths.append(t-pulse)
        rows=list(csv.DictReader((folder/name/'captures.csv').open()))
        assert len(rows)==len(publications)==7 and requests==8
        for row,(t,v) in zip(rows,publications): assert int(row['time_ns'])==t and int(row['code'],16)==v
        assert [v for _,v in publications]==[0,1,0xabc,4095,0x555,0xaaa,0x789]
        report[name]={'requests':requests,'published':7,'request_interval_ns':period,'valid_width_ns':sorted(set(widths))}
    transitions=[]; start=None
    for t,o,s in epochs(folder/'default_page'/'default_page.vcd'):
        if o.get('ready')=='0' and s.get('ready')=='1': start=t
        if s.get('ready')=='1' and 'led' in o and (int(o['led'],2)^int(s['led'],2))&64:
            transitions.append(t)
    assert len(transitions)==2 and transitions==[start+1e9,start+2e9]
    report['default_page']={'page_duration_ns':1000000000,'pair_duration_ns':2000000000}
    (folder/'waveform_report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report
