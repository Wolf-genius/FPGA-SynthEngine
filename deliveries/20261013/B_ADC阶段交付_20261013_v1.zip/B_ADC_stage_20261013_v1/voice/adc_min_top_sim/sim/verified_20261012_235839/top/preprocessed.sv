`timescale 1ns/1ps
`default_nettype none

// One MCP3208 single-ended conversion. All registers use the 50 MHz clk.
// start/channel must already be synchronous to clk. Pulse start for one cycle;
// it is accepted only in IDLE. Busy-time pulses are discarded, not queued.
// A start held into the next IDLE is a new request (not an edge detector).
// channel is captured as part of the command when the request is accepted.
// After reset an early request is accepted, but CS waits for a 2 us high guard.
// data changes only on reset or valid; valid lasts one clk cycle, busy is then 0.
// This module does not schedule scans or publish an eight-channel control frame.
module adc_spi (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [2:0]  channel,
    input  wire        miso,
    output reg         cs_n,
    output reg         sclk,
    output reg         mosi,
    output reg         busy,
    output reg  [11:0] data,
    output reg         valid
);
    // Fixed project timing: 50 MHz / (2*50) = 500 kHz.
    // Separate counters/limits keep the 2 us gap from changing SPI frequency.
    localparam integer HALF_CYCLES = 50;
    localparam integer CS_HIGH_CYCLES = 100;
    localparam [2:0] IDLE = 3'd0, SHIFT = 3'd1,
                     HOLD = 3'd2, GAP = 3'd3, WAIT_HIGH = 3'd4;

    reg [2:0] state;
    reg [6:0] count; // Must represent 99 for the 100-cycle CS-high gap.
    reg [4:0] bit_index;
    reg [23:0] tx_shift;
    reg [11:0] rx_shift;
    reg miso_meta;
    reg miso_sync;

    // DOUT changes after the external falling SCLK edge. At 500 kHz the
    // 1 us half-cycle allows the modeled 200 ns DOUT delay plus this pipeline.
    // RTL simulation does not prove metastability MTBF or physical IO timing.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            miso_meta <= 1'b0;
            miso_sync <= 1'b0;
        end else begin
            miso_meta <= miso;
            miso_sync <= miso_meta;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            count <= 7'd0;
            bit_index <= 5'd0;
            tx_shift <= 24'd0;
            rx_shift <= 12'd0;
            cs_n <= 1'b1;
            sclk <= 1'b0;
            mosi <= 1'b0;
            busy <= 1'b0;
            data <= 12'd0;
            valid <= 1'b0;
        end else begin
            valid <= 1'b0;
            case (state)
                IDLE: begin
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    // Saturating reset-recovery guard. Normal GAP completion
                    // preloads 100, so it does not add a second normal gap.
                    // 101 observed edges span >=100 full periods even when
                    // reset deassertion is asynchronous to clk.
                    if (count < CS_HIGH_CYCLES)
                        count <= count + 7'd1;
                    if (start) begin
                        // [23:19]=0, [18]=Start, [17]=single-ended,
                        // [16:14]=channel. CH0=060000, CH1=064000.
                        tx_shift <= {5'b00000, 2'b11, channel, 14'd0};
                        rx_shift <= 12'd0;
                        bit_index <= 5'd0;
                        busy <= 1'b1;
                        if (count == CS_HIGH_CYCLES) begin
                            count <= 7'd0;
                            cs_n <= 1'b0;
                            state <= SHIFT;
                        end else begin
                            state <= WAIT_HIGH;
                        end
                    end
                end
                WAIT_HIGH: begin
                    if (count == CS_HIGH_CYCLES) begin
                        count <= 7'd0;
                        cs_n <= 1'b0;
                        state <= SHIFT;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                SHIFT: begin
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        if (!sclk) begin
                            sclk <= 1'b1;
                            // Zero-based 12..23 = rising edges 13..24.
                            // Ignore the unknown prefix and edge-12 null.
                            if (bit_index >= 5'd12)
                                rx_shift <= {rx_shift[10:0], miso_sync};
                        end else begin
                            sclk <= 1'b0;
                            if (bit_index == 5'd23) begin
                                state <= HOLD;
                            end else begin
                                mosi <= tx_shift[22];
                                tx_shift <= {tx_shift[22:0], 1'b0};
                                bit_index <= bit_index + 5'd1;
                            end
                        end
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                HOLD: begin
                    // Keep CS low for 1 us after the final falling SCLK edge.
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        cs_n <= 1'b1;
                        mosi <= 1'b0;
                        state <= GAP;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                GAP: begin
                    // Remain busy until CS has been high for 2 us.
                    // The earliest next acceptance adds another clk cycle.
                    if (count == CS_HIGH_CYCLES - 1) begin
                        count <= 7'd100;
                        data <= rx_shift; // B0 was captured earlier in SHIFT.
                        valid <= 1'b1;
                        busy <= 1'b0;
                        state <= IDLE;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                default: begin
                    state <= IDLE;
                    count <= 7'd0;
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    busy <= 1'b0;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Logical LEDs: [5:0] data, [6] high-page flag, [7] acquisition activity.
// One snapshot spans BOTH pages. A new valid on the high->low boundary wins.
module adc_led_pages #(parameter integer PAGE_CYCLES=50_000_000)(
 input wire clk, rst_n, input wire [11:0] data, input wire valid,
 output wire [7:0] led_on, output reg [11:0] snapshot,
 output reg ready
);
 localparam integer W=(PAGE_CYCLES<2)?1:$clog2(PAGE_CYCLES);
 reg [W-1:0] count;
 reg page, activity, fresh;
 reg [11:0] latest;
 assign led_on=ready ? {activity,page,(page?snapshot[11:6]:snapshot[5:0])}:8'd0;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; page<=0; activity<=0; fresh<=0;
   latest<=0; snapshot<=0; ready<=0;
  end else begin
   if(valid) begin latest<=data; fresh<=1; end
   if(!ready) begin
    if(valid) begin
     snapshot<=data; ready<=1; activity<=1; fresh<=0; count<=0;
    end
   end else if(count==PAGE_CYCLES-1) begin
    count<=0; page<=~page;
    if(page) begin
     snapshot<=valid?data:latest;
     if(fresh || valid) activity<=~activity;
     fresh<=0;
    end
   end else count<=count+1'b1;
  end
 end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// rst_n must be released synchronously. Parameters must be positive integers.
// Tick while busy is skipped, never queued; missed_tick lasts one clock.
module adc_min_core #(
 parameter integer SAMPLE_CYCLES=50_000, PAGE_CYCLES=50_000_000
)(
 input wire clk,rst_n,miso,
 output wire cs_n,sclk,mosi,
 output reg sample_start, output wire sample_busy,
 output reg [11:0] sample_data, output reg sample_valid, missed_tick,
 output wire [7:0] led_on, output wire [11:0] snapshot, output wire ready
);
 localparam integer W=(SAMPLE_CYCLES<2)?1:$clog2(SAMPLE_CYCLES);
 reg [W-1:0] count;
 wire [11:0] spi_data;
 wire spi_valid;
 adc_spi spi(.clk(clk),.rst_n(rst_n),.start(sample_start),.channel(3'd0),
  .miso(miso),.cs_n(cs_n),.sclk(sclk),.mosi(mosi),.busy(sample_busy),
  .data(spi_data),.valid(spi_valid));
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; sample_start<=0; sample_data<=0; sample_valid<=0; missed_tick<=0;
  end else begin
   sample_start<=0; missed_tick<=0; sample_valid<=spi_valid;
   if(spi_valid) sample_data<=spi_data;
   if(count==SAMPLE_CYCLES-1) begin
    count<=0;
    if(!sample_busy && !sample_start) sample_start<=1;
    else missed_tick<=1;
   end else count<=count+1'b1;
  end
 end
 adc_led_pages #(.PAGE_CYCLES(PAGE_CYCLES)) display_pages(
  .clk(clk),.rst_n(rst_n),.data(sample_data),.valid(sample_valid),
  .led_on(led_on),.snapshot(snapshot),.ready(ready));
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Standalone CH0 test top. A must verify LED pins/polarity and CST/SDC.
// Do NOT reuse the reference PMOD LED pins: four overlap ADC SPI.
// LED_INVERT_MASK bit=1 means the corresponding physical LED is active low.
module adc_min_top #(
 parameter integer SAMPLE_CYCLES=50_000, PAGE_CYCLES=50_000_000,
 parameter [7:0] LED_INVERT_MASK=8'h00
)(
 input wire sys_clk,rst_n,adc_miso,
 output wire adc_cs_n,adc_sclk,adc_mosi,
 output wire [7:0] led
);
 reg [1:0] reset_release;
 always @(posedge sys_clk or negedge rst_n)
  if(!rst_n) reset_release<=2'b00;
  else reset_release<={reset_release[0],1'b1};
 wire [7:0] led_on;
 // Named internal nets available for later Analyzer integration, not extra IO.
 wire [11:0] sample_data,snapshot;
 wire sample_start,sample_busy,sample_valid,missed_tick,ready;
 adc_min_core #(.SAMPLE_CYCLES(SAMPLE_CYCLES),.PAGE_CYCLES(PAGE_CYCLES)) core(
  .clk(sys_clk),.rst_n(reset_release[1]),.miso(adc_miso),
  .cs_n(adc_cs_n),.sclk(adc_sclk),.mosi(adc_mosi),
  .sample_start(sample_start),.sample_busy(sample_busy),.sample_data(sample_data),
  .sample_valid(sample_valid),.missed_tick(missed_tick),.led_on(led_on),
  .snapshot(snapshot),.ready(ready));
 assign led=led_on^LED_INVERT_MASK;
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none

// Behavioral digital protocol model, not an analog converter model.
// Only the external SPI pins select the channel. No DUT hierarchy is used.
// Search for Start, then decode SGL and D2..D0 relative to that Start.
module mcp3208_model (
    input wire rst_n,
    input wire cs_n,
    input wire sclk,
    input wire mosi,
    input wire [95:0] channel_values,
    input integer dout_delay_ns,
    output reg miso,
    output reg [2:0] decoded_channel,
    output reg [11:0] selected_value,
    output reg [23:0] command_seen,
    output integer rise_count,
    output integer start_edge
);
    reg started;
    integer after_start;
    integer frame_id = 0;
    integer scheduled_frame;
    reg scheduled_bit;

    initial miso = 1'bx;

    always @(negedge cs_n) begin
        frame_id = frame_id + 1;
        rise_count = 0;
        start_edge = 0;
        after_start = 0;
        started = 0;
        decoded_channel = 0;
        selected_value = 12'hxxx;
        command_seen = 0;
        miso = 1'bx;
    end

    always @(posedge sclk) begin
        if (rst_n && !cs_n) begin
            rise_count = rise_count + 1;
            command_seen = {command_seen[22:0], mosi};
            if (!started) begin
                if (mosi === 1'b1) begin
                    started = 1;
                    start_edge = rise_count;
                    after_start = 0;
                end else if (mosi !== 1'b0)
                    $fatal(1, "MODEL unknown DIN before Start");
            end else begin
                after_start = after_start + 1;
                case (after_start)
                    1: if (mosi !== 1'b1)
                           $fatal(1, "MODEL expected single-ended SGL=1");
                    2: decoded_channel[2] = mosi;
                    3: decoded_channel[1] = mosi;
                    4: begin
                        decoded_channel[0] = mosi;
                        if (^decoded_channel === 1'bx)
                            $fatal(1, "MODEL unknown channel bits");
                        selected_value = channel_values[12*decoded_channel +: 12];
                    end
                endcase
            end
        end
    end

    always @(negedge sclk) begin
        if (rst_n && !cs_n) begin
            scheduled_frame = frame_id;
            if (started && after_start == 5)
                scheduled_bit = 1'b0; // Null, received on the next rising edge.
            else if (started && after_start >= 6 && after_start <= 17)
                scheduled_bit = selected_value[17-after_start];
            else
                scheduled_bit = 1'bx;
            #(dout_delay_ns);
            if (rst_n && !cs_n && frame_id == scheduled_frame)
                miso = scheduled_bit;
        end
    end

    always @(posedge cs_n or negedge rst_n)
        miso = 1'bx;
endmodule
`default_nettype wire
`timescale 1ns/1ps
module tb_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0; wire miso,cs_n,sclk,mosi,cs2,sc2,mo2;
 wire [7:0] led,led2; reg [95:0] values=96'habc;
 wire [2:0] ch; wire [11:0] val; wire [23:0] cmd; wire integer rises,se;
 integer cycles=0,starts=0; time previous_start=0;
 adc_min_top #(.PAGE_CYCLES(5000)) dut(clk,rst_n,miso,cs_n,sclk,mosi,led);
 adc_min_top #(.PAGE_CYCLES(5000),.LED_INVERT_MASK(8'hff)) inverted(clk,rst_n,miso,cs2,sc2,mo2,led2);
 mcp3208_model model(rst_n,cs_n,sclk,mosi,values,200,miso,ch,val,cmd,rises,se);
 always @(posedge clk) begin
  if(!rst_n) cycles=0; else cycles=cycles+1;
  #1;
  if(led2!==~led || {cs2,sc2,mo2}!=={cs_n,sclk,mosi}) $fatal(1,"Polarity or wrapper mismatch");
 end
 always @(negedge cs_n) begin
  if(starts==0 && cycles!=50003) $fatal(1,"Reset release/first request: %0d",cycles);
  if(previous_start && $time-previous_start!=1000000) $fatal(1,"Top period");
  starts=starts+1; previous_start=$time;
 end
 initial begin
  $dumpfile("top.vcd"); $dumpvars(0,rst_n,cs_n,sclk,mosi,miso,led,led2);
  #107; rst_n=1;
  wait(led[7]); #1; if(led[6:0]!==7'h3c) $fatal(1,"Initial ABC low");
  @(posedge led[6]); #1; if(led[5:0]!==6'h2a) $fatal(1,"ABC high");
  @(negedge cs_n); repeat(14) @(posedge sclk); #17; rst_n=0;
  #1; if(led!==0 || led2!==8'hff || cs_n!==1 || sclk!==0) $fatal(1,"Async reset");
  starts=0; previous_start=0; cycles=0; #1; rst_n=1;
  wait(led[7]); #1; if(led[6:0]!==7'h3c) $fatal(1,"Recovery");
  $display("PASS ALL top default_1ms reset_release_2clks polarity_masks=00,FF short_reset_ns=2 recovery=ABC"); $finish;
 end
 initial begin #5000000; $fatal(1,"Timeout"); end
endmodule
