`timescale 1ns/1ps
`default_nettype none
// Logical LEDs: [5:0] data, [6] high-page flag, [7] acquisition activity.
// One snapshot spans BOTH pages. A new valid on the high->low boundary wins.
module adc_led_pages #(parameter integer PAGE_CYCLES=50_000_000)(
 input wire clk, rst_n, input wire [11:0] data, input wire valid,
 output wire [7:0] led_on, output reg [11:0] snapshot,
 output reg ready
);
 localparam integer W=(PAGE_CYCLES<2)?1:$clog2(PAGE_CYCLES);
 reg [W-1:0] count;
 reg page, activity, fresh;
 reg [11:0] latest;
 assign led_on=ready ? {activity,page,(page?snapshot[11:6]:snapshot[5:0])}:8'd0;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; page<=0; activity<=0; fresh<=0;
   latest<=0; snapshot<=0; ready<=0;
  end else begin
   if(valid) begin latest<=data; fresh<=1; end
   if(!ready) begin
    if(valid) begin
     snapshot<=data; ready<=1; activity<=1; fresh<=0; count<=0;
    end
   end else if(count==PAGE_CYCLES-1) begin
    count<=0; page<=~page;
    if(page) begin
     snapshot<=valid?data:latest;
     if(fresh || valid) activity<=~activity;
     fresh<=0;
    end
   end else count<=count+1'b1;
  end
 end
endmodule
`default_nettype wire
`timescale 1ns/1ps
module tb_pages;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,valid=0; reg [11:0] data=0;
 wire [7:0] led; wire [11:0] snapshot; wire ready;
 adc_led_pages #(.PAGE_CYCLES(4)) dut(clk,rst_n,data,valid,led,snapshot,ready);
 integer i; reg [5:0] low_bits; reg activity_before;
 task step(input bit v,input [11:0] d);
  @(negedge clk); valid=v; data=d; @(posedge clk); #1;
 endtask
 initial begin
  $dumpfile("pages.vcd"); $dumpvars(0, rst_n,valid,data,led,snapshot,ready);
  #25; rst_n=1;
  step(0,12'hfff); if(ready || led!==0) $fatal(1,"No valid must remain blank");
  step(1,0);
  for(i=0;i<4096;i=i+1) begin
   if(snapshot!==i[11:0] || led[6:0]!=={1'b0,i[5:0]}) $fatal(1,"Low page %d",i);
   low_bits=led[5:0];
   step(1,~i[11:0]); step(0,0); step(0,0);
   step(1,12'h123); // valid exactly at low->high must NOT replace snapshot
   if(led[6]!==1 || {led[5:0],low_bits}!==i[11:0]) $fatal(1,"Torn pair %d",i);
   step(0,0); step(0,0); step(0,0);
   step(1,(i+1)&4095); // new value exactly at high->low must win
  end
  $display("PASS exhaustive_12bit_pairs=4096 boundary_valid_priority=8192");
  // Drain the last fresh result, then verify activity stops without valids.
  repeat(8) step(0,12'hfff);
  activity_before=led[7];
  repeat(16) begin step(0,12'h555); if(snapshot!==0 || led[7]!==activity_before) $fatal(1,"Stale data/activity"); end
  #3; rst_n=0; #1; if(led!==0 || snapshot!==0 || ready!==0) $fatal(1,"Reset");
  #17; rst_n=1; step(1,12'habc);
  repeat(4) step(0,0);
  if(led[6]!==1) $fatal(1,"High page expected");
  #3; rst_n=0; #1; if(led!==0 || ready!==0) $fatal(1,"High page reset");
  $display("PASS ALL pages stale_hold reset_both_pages"); $finish;
 end
 initial begin #1000000; $fatal(1,"Timeout"); end
endmodule
