`timescale 1ns/1ps
`default_nettype none
// Logical LEDs: [5:0] data, [6] high-page flag, [7] acquisition activity.
// One snapshot spans BOTH pages. A new valid on the high->low boundary wins.
module adc_led_pages #(parameter integer PAGE_CYCLES=50_000_000)(
 input wire clk, rst_n, input wire [11:0] data, input wire valid,
 output wire [7:0] led_on, output reg [11:0] snapshot,
 output reg ready
);
 localparam integer W=(PAGE_CYCLES<2)?1:$clog2(PAGE_CYCLES);
 reg [W-1:0] count;
 reg page, activity, fresh;
 reg [11:0] latest;
 assign led_on=ready ? {activity,page,(page?snapshot[11:6]:snapshot[5:0])}:8'd0;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; page<=0; activity<=0; fresh<=0;
   latest<=0; snapshot<=0; ready<=0;
  end else begin
   if(valid) begin latest<=data; fresh<=1; end
   if(!ready) begin
    if(valid) begin
     snapshot<=data; ready<=1; activity<=1; fresh<=0; count<=0;
    end
   end else if(count==PAGE_CYCLES-1) begin
    count<=0; page<=~page;
    if(page) begin
     snapshot<=valid?data:latest;
     if(fresh || valid) activity<=~activity;
     fresh<=0;
    end
   end else count<=count+1'b1;
  end
 end
endmodule
`default_nettype wire
`timescale 1ns/1ps
module tb_default_page;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,valid=0; reg [11:0] data=12'habc;
 wire [7:0] led; wire [11:0] snapshot; wire ready;
 time t0,t1;
 adc_led_pages dut(clk,rst_n,data,valid,led,snapshot,ready);
 initial begin
  $dumpfile("default_page.vcd"); $dumpvars(0,rst_n,valid,data,led,snapshot,ready);
  #25; rst_n=1; @(negedge clk); valid=1;
  @(posedge ready); t0=$time;
  @(negedge clk); data=12'h555;
  @(negedge clk); valid=0;
  @(posedge led[6]); t1=$time; #1;
  if(t1-t0!=1000000000 || snapshot!==12'habc || led[5:0]!==6'h2a) $fatal(1,"Default high");
  $display("PASS default_low_page_ns=%0d snapshot=%h",t1-t0,snapshot);
  @(negedge led[6]); #1;
  if($time-1-t1!=1000000000 || snapshot!==12'h555) $fatal(1,"Default low");
  $display("PASS ALL default_page two_pages_ns=2000000000 new_snapshot=%h",snapshot); $finish;
 end
 initial begin #2100000000; $fatal(1,"Timeout"); end
endmodule
