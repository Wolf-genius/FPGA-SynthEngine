`timescale 1ns/1ps
`default_nettype none
// rst_n must be released synchronously. Parameters must be positive integers.
// Tick while busy is skipped, never queued; missed_tick lasts one clock.
module adc_min_core #(
 parameter integer SAMPLE_CYCLES=50_000, PAGE_CYCLES=50_000_000
)(
 input wire clk,rst_n,miso,
 output wire cs_n,sclk,mosi,
 output reg sample_start, output wire sample_busy,
 output reg [11:0] sample_data, output reg sample_valid, missed_tick,
 output wire [7:0] led_on, output wire [11:0] snapshot, output wire ready
);
 localparam integer W=(SAMPLE_CYCLES<2)?1:$clog2(SAMPLE_CYCLES);
 reg [W-1:0] count;
 wire [11:0] spi_data;
 wire spi_valid;
 adc_spi spi(.clk(clk),.rst_n(rst_n),.start(sample_start),.channel(3'd0),
  .miso(miso),.cs_n(cs_n),.sclk(sclk),.mosi(mosi),.busy(sample_busy),
  .data(spi_data),.valid(spi_valid));
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; sample_start<=0; sample_data<=0; sample_valid<=0; missed_tick<=0;
  end else begin
   sample_start<=0; missed_tick<=0; sample_valid<=spi_valid;
   if(spi_valid) sample_data<=spi_data;
   if(count==SAMPLE_CYCLES-1) begin
    count<=0;
    if(!sample_busy && !sample_start) sample_start<=1;
    else missed_tick<=1;
   end else count<=count+1'b1;
  end
 end
 adc_led_pages #(.PAGE_CYCLES(PAGE_CYCLES)) display_pages(
  .clk(clk),.rst_n(rst_n),.data(sample_data),.valid(sample_valid),
  .led_on(led_on),.snapshot(snapshot),.ready(ready));
endmodule
`default_nettype wire
