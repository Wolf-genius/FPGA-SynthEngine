`timescale 1ns/1ps
`default_nettype none
// Standalone CH0 test top. A must verify LED pins/polarity and CST/SDC.
// Do NOT reuse the reference PMOD LED pins: four overlap ADC SPI.
// LED_INVERT_MASK bit=1 means the corresponding physical LED is active low.
module adc_min_top #(
 parameter integer SAMPLE_CYCLES=50_000, PAGE_CYCLES=50_000_000,
 parameter [7:0] LED_INVERT_MASK=8'h00
)(
 input wire sys_clk,rst_n,adc_miso,
 output wire adc_cs_n,adc_sclk,adc_mosi,
 output wire [7:0] led
);
 reg [1:0] reset_release;
 always @(posedge sys_clk or negedge rst_n)
  if(!rst_n) reset_release<=2'b00;
  else reset_release<={reset_release[0],1'b1};
 wire [7:0] led_on;
 // Named internal nets available for later Analyzer integration, not extra IO.
 wire [11:0] sample_data,snapshot;
 wire sample_start,sample_busy,sample_valid,missed_tick,ready;
 adc_min_core #(.SAMPLE_CYCLES(SAMPLE_CYCLES),.PAGE_CYCLES(PAGE_CYCLES)) core(
  .clk(sys_clk),.rst_n(reset_release[1]),.miso(adc_miso),
  .cs_n(adc_cs_n),.sclk(adc_sclk),.mosi(adc_mosi),
  .sample_start(sample_start),.sample_busy(sample_busy),.sample_data(sample_data),
  .sample_valid(sample_valid),.missed_tick(missed_tick),.led_on(led_on),
  .snapshot(snapshot),.ready(ready));
 assign led=led_on^LED_INVERT_MASK;
endmodule
`default_nettype wire
