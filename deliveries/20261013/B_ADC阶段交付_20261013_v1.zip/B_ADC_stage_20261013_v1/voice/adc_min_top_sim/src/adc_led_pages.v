`timescale 1ns/1ps
`default_nettype none
// Logical LEDs: [5:0] data, [6] high-page flag, [7] acquisition activity.
// One snapshot spans BOTH pages. A new valid on the high->low boundary wins.
module adc_led_pages #(parameter integer PAGE_CYCLES=50_000_000)(
 input wire clk, rst_n, input wire [11:0] data, input wire valid,
 output wire [7:0] led_on, output reg [11:0] snapshot,
 output reg ready
);
 localparam integer W=(PAGE_CYCLES<2)?1:$clog2(PAGE_CYCLES);
 reg [W-1:0] count;
 reg page, activity, fresh;
 reg [11:0] latest;
 assign led_on=ready ? {activity,page,(page?snapshot[11:6]:snapshot[5:0])}:8'd0;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   count<=0; page<=0; activity<=0; fresh<=0;
   latest<=0; snapshot<=0; ready<=0;
  end else begin
   if(valid) begin latest<=data; fresh<=1; end
   if(!ready) begin
    if(valid) begin
     snapshot<=data; ready<=1; activity<=1; fresh<=0; count<=0;
    end
   end else if(count==PAGE_CYCLES-1) begin
    count<=0; page<=~page;
    if(page) begin
     snapshot<=valid?data:latest;
     if(fresh || valid) activity<=~activity;
     fresh<=0;
    end
   end else count<=count+1'b1;
  end
 end
endmodule
`default_nettype wire
