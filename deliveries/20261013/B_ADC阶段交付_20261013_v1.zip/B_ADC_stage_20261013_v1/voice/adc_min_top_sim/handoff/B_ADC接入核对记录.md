# B的ADC工程接入准备核对

核对日期：2026-10-13。用户要求先解释GPRJ/CST/SDC，并仅完成B应该做的部分。

**本轮完成：B的工程接入说明、正式RTL/仿真文件清单、端口/接线/时序需求及版本核对。** 实际GPRJ/CST/SDC仍由A负责，未创建或修改；未运行Gowin、未重跑功能仿真、未打包或发消息给A。

主入口：[B_ADC工程接入说明](B_ADC工程接入说明.md)。机器清单：[B_ADC接入清单.json](B_ADC接入清单.json)。本轮原始核对结果：[核对报告.json](checked_20261013_150231_985432/核对报告.json)。

| 检查项 | 结果 | 具体证据 |
|---|---|---|
| 正式RTL文件齐全且与已验收版本一致 | 通过 | 核对报告source_checks：4个文件各有预期/实际SHA256及MATCH；包括同级adc_spi_sim中的共享驱动 |
| 模块依赖与顶层名称 | 通过（源码静态核对） | module_dependency_check：唯一模块adc_min_top/adc_min_core/adc_led_pages/adc_spi；顶层为adc_min_top，未发现未列的include/readmem文件依赖 |
| 端口名、方向、位宽与默认参数 | 通过（源码静态核对） | top_port_check从RTL头部解析并对比清单：7组端口、14个I/O位，adc_miso为input；两个周期参数和极性默认值匹配源码 |
| 最小top与SPI既有证据版本关系 | 通过（完整性核对） | evidence_checks分别51项与20项哈希记录全部MATCH，含当前源码、工具日志、CSV、VCD及编译产物；不是重新验收功能 |
| 已有验证状态和工具限制 | 如实保留 | 两份旧manifest均为PASS；最小top各步exit0；SPI外层探测3221225477已记录，实际运行文件不是driver_probe.vvp，替代流程结果未写成工具恢复 |
| 说明中的本地文件链接 | 通过 | document_links_checked：检查每个链接目标存在；数量见原始报告 |
| SPI接线需求 | 已整理，最终工程/实物待复核 | 按既有接线记录列R18/CS、T18/CLK、P16/DIN、R17/DOUT；方向与芯片脚号有依据，不新增选脚 |
| LED实际位置和极性 | 待确认 | 参考8灯前四脚与SPI冲突；清单led候选球号和电平为空，保留给A按实物核对 |
| A收到/复核资料 | 待确认 | 未发送消息、未代填签字 |
| GPRJ/CST/SDC及Gowin构建 | 未完成/未验证 | 属于A任务，不因B资料准备通过而勾选完成 |
| 固定电压实测 | 未验证 | 等可用工程后由B完成测量及完整数字码记录，A配合 |

接入核对入口为 [check_handoff.py](check_handoff.py)。从handoff目录执行 `python -B check_handoff.py`，新建checked目录并保存报告；检查失败会退出非零，不覆盖旧证据。此次命令和检查脚本/资料哈希也记录在报告中。

已有功能仿真通过项详见[最小顶层验证记录](../最小顶层验证记录.md)。本轮没有改变RTL/TB、时钟/采样/硬件参数，也没有用文件完整性核对代替功能、综合、时序或实物验收。
