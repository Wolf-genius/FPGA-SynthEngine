"""Read-only source/evidence audit; writes a fresh handoff report, never a build."""
import hashlib
import json
from pathlib import Path
import re
import sys
from datetime import datetime, timedelta, timezone

sys.stdout.reconfigure(encoding="utf-8")
here = Path(__file__).resolve().parent
voice = here.parents[1]
manifest_path = here / "B_ADC接入清单.json"
document_path = here / "B_ADC工程接入说明.md"
stamp = datetime.now(timezone(timedelta(hours=8)))
out = here / ("checked_" + stamp.strftime("%Y%m%d_%H%M%S_%f"))
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = {
    "status": "INCOMPLETE", "checked_at": stamp.isoformat(),
    "scope": "B handoff paths, ports, dependencies and existing evidence integrity only; no new simulation or Gowin/board acceptance",
    "command": [sys.executable, "-B", str(Path(__file__).resolve())],
    "checker_sha256": sha(Path(__file__).resolve()),
    "handoff_manifest_sha256": sha(manifest_path),
    "handoff_document_sha256": sha(document_path),
    "source_checks": [], "evidence_checks": [],
    "remaining_status": {"A_receipt": "待确认", "physical_LEDs": "待确认",
        "GPRJ_CST_SDC": "未完成", "Gowin_timing_bitstream": "未验证", "ADC_voltage_measurement": "未验证"}
}

try:
    spec = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert spec["path_base"] == "voice/"
    sources = {}
    for entry in spec["synthesis_sources"]:
        p = (voice / entry["path"]).resolve()
        assert p.is_relative_to(voice) and p.is_file(), entry["path"]
        actual = sha(p)
        assert actual == entry["sha256"], f"Source changed: {p}"
        code = re.sub(r"//[^\n]*", "", p.read_text(encoding="utf-8"))
        modules = re.findall(r"\bmodule\s+(\w+)", code)
        assert modules == [entry["module"]], (p, modules)
        assert not re.search(r"`include|\$readmem[hb]", code), "Unlisted file dependency"
        sources[entry["module"]] = code
        report["source_checks"].append({**entry, "actual_sha256": actual, "result": "MATCH"})
    assert set(sources) == {"adc_min_top", "adc_min_core", "adc_led_pages", "adc_spi"}
    for parent, children in spec["module_dependencies"].items():
        for child in children:
            assert child in sources and re.search(r"\b" + child + r"\s*(?:#\s*\(|\w+\s*\()", sources[parent])
    assert spec["top_module"] == "adc_min_top"
    top = sources["adc_min_top"]
    match = re.search(r"module\s+adc_min_top\s*#\s*\(.*?\)\s*\((.*?)\)\s*;", top, re.S)
    assert match, "Top header missing"
    header = match[1]
    ports = {}
    for group in re.finditer(r"\b(input|output)\s+wire\s*(\[\s*\d+\s*:\s*\d+\s*\])?\s*(.*?)(?=\b(?:input|output)\b|$)", header, re.S):
        width = 1
        if group[2]:
            a, b = map(int, re.findall(r"\d+", group[2])); width = abs(a-b)+1
        for name in group[3].strip().strip(",").split(","):
            name = name.strip()
            assert re.fullmatch(r"\w+", name), name
            ports[name] = {"direction": group[1], "width": width}
    expected = {p["name"]: {"direction": p["direction"], "width": p["width"]} for p in spec["top_ports"]}
    assert ports == expected, (ports, expected)
    assert ports["adc_miso"]["direction"] == "input"
    for name, value in spec["default_parameters"].items():
        assert re.search(r"\b"+name+r"\s*=\s*"+re.escape(value)+r"\b", top), name
    report["top_port_check"] = {"result": "MATCH", "groups": len(ports),
        "total_io_bits": sum(p["width"] for p in ports.values()), "parsed_ports": ports}
    report["module_dependency_check"] = {"result": "MATCH", "modules": list(sources)}
    for ref in spec["verification_evidence"]:
        p = voice / ref["manifest"]
        m = json.loads(p.read_text(encoding="utf-8"))
        assert m["status"] == "PASS", str(p)
        checked = []
        for field, anchor in [("input_sha256", voice/ref["source_root"]), ("output_sha256", p.parent)]:
            for name, expected_sha in m[field].items():
                f = (anchor/name).resolve()
                assert f.is_relative_to(voice) and sha(f) == expected_sha, str(f)
                checked.append({"kind": field, "path": str(f.relative_to(voice)), "sha256": expected_sha, "result": "MATCH"})
        for step in m["steps"]:
            if step["exit_code"]:
                assert ref["kind"] == "single_spi" and step.get("name") == "03_driver_probe" and step["exit_code"] == 3221225477
                assert m["executed_vvp"] != "driver_probe.vvp"
        report["evidence_checks"].append({"manifest": ref["manifest"], "manifest_sha256": sha(p),
            "original_completed_at": m["completed_at"], "hash_matches": len(checked), "files": checked})
    links = re.findall(r"\]\(([^)]+)\)", document_path.read_text(encoding="utf-8"))
    for link in links:
        assert (here/link).is_file(), link
    report["document_links_checked"] = len(links)
    report["status"] = "PASS"
except Exception as error:
    report["status"] = "FAILED"; report["error"] = repr(error)
finally:
    (out/"核对报告.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "report": str(out/"核对报告.json"),
        "source_matches": len(report["source_checks"]),
        "historical_evidence_hash_matches": sum(e["hash_matches"] for e in report["evidence_checks"])}, ensure_ascii=False))
if report["status"] != "PASS":
    raise SystemExit(1)
