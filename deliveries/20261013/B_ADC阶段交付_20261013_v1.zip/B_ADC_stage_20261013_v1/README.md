# B ADC原始采集层阶段交付包

交付日期：2026-10-13。此包交付B的当前源码、测试、仿真证据和A/B讨论资料。**不是可直接下载的Gowin工程，不含ADC专用GPRJ/CST/SDC或有效ADC码流；没有虚构综合、时序、下载或真实测量结果。**

先读[B与A的总结和流程图](B与A_ADC阶段总结与协作流程_20261013.md)，再读[最小工程接入说明](voice/adc_min_top_sim/handoff/B_ADC工程接入说明.md)。

## 包里有什么

- voice/adc_spi_sim：单次驱动、独立ADC模型、TB、运行/断言脚本和唯一最终历史证据224506。
- voice/adc_scan_sim：八路原始扫描、控制器故障测试和唯一最终历史证据232222；raw_frame不是正式gate/key_gain/controls_valid。
- voice/adc_min_top_sim：CH0最小逻辑top、12位双页观察、四份TB/五组测试、唯一最终历史证据235839，及B的接入/实测资料。
- 根目录计划、规则和进度快照、器件/接线说明，以及器件资料/、output/pdf/的相关参考材料，保留相对目录。
- [文件清单.json](文件清单.json)、[SHA256SUMS.txt](SHA256SUMS.txt)、[文档引用核对](文档引用核对.json)和核对脚本。

三个旧验证记录中的“尚未打包”等属于当时快照；日志/manifest/原文不改写。包内进度记录是打包前快照，本次交付范围以本README和总结为准。原型adc_ch0、音频、光弦、GPIO自检及失败/中间开发运行不作为本包实现；缺失的旧文档或外部项目引用见文档引用核对，不假造内容。

## A先怎么接入

CH0最小工程只加入这四个正式RTL，顶层设置adc_min_top：

1. voice/adc_spi_sim/src/adc_spi.v
2. voice/adc_min_top_sim/src/adc_led_pages.v
3. voice/adc_min_top_sim/src/adc_min_core.v
4. voice/adc_min_top_sim/src/adc_min_top.v

TB、模型、Python和历史编译产物不加入Gowin综合。八路扫描另目录交付，首次CH0测试不混编。包内全引脚CST是厂家参考文本，不是ADC约束，禁止整份加入本工程。参考LED前四脚与SPI冲突；A须落实无冲突8灯或Analyzer。R17正式MISO必须输入。

## 怎样核对和重新仿真

需要本机Python 3.9以上和完整Icarus安装。本次验证环境是Windows、Icarus 12 devel；不内置工具软件。另电脑复现能力尚未实测。三个运行脚本支持--iverilog与--vvp参数，按实际安装路径填写；默认D:/iverilog仅是原机位置。

**请解压到全英文路径，例如D:/adc_delivery/B_ADC_stage_20261013_v1。ZIP内部根目录已采用英文名。** 本次实际复现发现含中文目录会使当前ivl输出路径乱码、编译失败；失败日志另存交付核验/失败路径复现，失败产物未执行。全英文目录是已验证的替代条件；没有修改RTL或声称工具编码问题已修复。

在包根运行 `python -B 核对交付包.py` 只读核对文件哈希；不会执行历史编译产物。

随后可在包根运行下列命令，**每次由脚本新建目录、重新编译当前源码**：

```powershell
python -B voice/adc_spi_sim/sim/run_basic.py --iverilog 'D:/iverilog/bin/iverilog.exe' --vvp 'D:/iverilog/bin/vvp.exe'
python -B voice/adc_scan_sim/sim/run_scan.py --iverilog 'D:/iverilog/bin/iverilog.exe' --vvp 'D:/iverilog/bin/vvp.exe'
python -B voice/adc_min_top_sim/sim/run_min.py --iverilog 'D:/iverilog/bin/iverilog.exe' --vvp 'D:/iverilog/bin/vvp.exe'
```

最小top的默认页周期测试模拟2秒，可能需要数分钟。当前外层Icarus已知0xC0000005异常，脚本用同一安装的预处理/底层ivl分阶段替代；这不是工具已恢复，也不代替Gowin综合。所有旧.vvp均只用于证据归档，**不能作为复现入口**；尤其driver_probe.vvp是失败外层工具产物，明确禁止运行。其原路径及哈希保留以保持原始manifest完整。旧compile.conf和日志中的绝对路径只作历史溯源，不复制执行。

## 接下来谁做什么

B已提供采集模块与仿真资料；A负责实际观察路径、工程/约束、构建检查和对应码流/下载；之后B按[实测步骤](voice/adc_min_top_sim/handoff/B_ADC构建配合与实测步骤.md)测真实电压与原始码，填写[空白表](voice/adc_min_top_sim/handoff/B_ADC实测记录模板.md)。A/B按问题归属修复，变更后重建、重测。

真实电气/数值、压力校准/控制帧、综合/PnR/时序/码流/下载、整机音频与总延迟仍未验证；A接收/人员复核待确认。本次打包不自动完成这些项目。

## 本次交付核验结果

本机从候选ZIP解压副本重新编译并运行三套测试，均通过；最终包正式源码、TB和脚本与该副本逐项同哈希。新增证据不替代原始证据，也不代表异机/Gowin/实物通过。

[复现结果](交付核验/复现结果.json)：

- adc_spi_sim：PASS，[新manifest](交付核验/重新编译证据/adc_spi_sim/manifest.json)。
- adc_scan_sim：PASS，[新manifest](交付核验/重新编译证据/adc_scan_sim/manifest.json)。
- adc_min_top_sim：PASS，[新manifest](交付核验/重新编译证据/adc_min_top_sim/manifest.json)。
