"""Check packaged files and source-bound archived evidence. Never execute .vvp."""
import hashlib,json,sys
from pathlib import Path
base=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checked=0
for line in (base/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    expected,rel=line.split('  ',1); p=(base/rel).resolve()
    assert p.is_relative_to(base) and p.is_file() and sha(p)==expected,rel
    checked+=1
inventory=json.loads((base/'文件清单.json').read_text(encoding='utf-8'))
for row in inventory['files']:
    p=base/row['path']; assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
references=0
for module,stamp in [('adc_spi_sim','224506'),('adc_scan_sim','232222'),('adc_min_top_sim','235839')]:
    source=base/'voice'/module
    evidence_sets=[source/'sim'/('verified_20261012_'+stamp)]
    fresh=base/'交付核验/重新编译证据'/module
    if fresh.is_dir(): evidence_sets.append(fresh)
    for evidence in evidence_sets:
        m=json.loads((evidence/'manifest.json').read_text(encoding='utf-8')); assert m['status']=='PASS'
        for field,anchor in [('input_sha256',source),('output_sha256',evidence)]:
            for relative,expected in m[field].items():
                p=(anchor/relative.replace('\\','/')).resolve()
                assert p.is_relative_to(base) and sha(p)==expected,str(p)
                references+=1
print(json.dumps({'status':'PASS','packaged_file_hashes':checked,'evidence_hash_references':references,'scope':'integrity only, no Gowin or board acceptance'},ensure_ascii=False))
