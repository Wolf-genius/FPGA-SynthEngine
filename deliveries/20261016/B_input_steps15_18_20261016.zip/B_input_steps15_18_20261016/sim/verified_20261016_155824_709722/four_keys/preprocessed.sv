`timescale 1ns/1ps
`default_nettype none
// Adapted from one_key/rtl/input/pressure_ch0_controls.v; arithmetic unchanged.
// Exact pressure mapping with registered multiply and restoring division.
// Accepts one raw sample per clock; publishes at acceptance edge E+19
// (380 ns at 50 MHz), with the same arithmetic as the source implementation.
module pressure_key_filter #(
    parameter [11:0] TON = 12'd256, TOFF = 12'd128,
    parameter [11:0] RAW_MIN = 12'd128, RAW_MAX = 12'd3840,
    parameter [15:0] MIN_GAIN = 16'd4096
)(
    input wire clk, rst_n,
    input wire [11:0] raw_data,
    input wire raw_valid,
    // Synchronous failed-round notification: flush pending work/confirmation;
    // preserve the last held state and smoothing history. Priority over raw_valid.
    input wire frame_cancel,
    output reg gate,
    output reg [15:0] key_gain,
    output reg controls_valid
);
    localparam [11:0] SPAN = RAW_MAX - RAW_MIN;
    localparam [15:0] GAIN_SPAN = 16'd65535 - MIN_GAIN;
    // Clamp and subtract before the registered multiply. The two endpoints
    // still map exactly to MIN_GAIN / 65535, including out-of-range inputs.
    reg [11:0] delta_raw, clamped_raw;
    reg clamp_valid;
    reg [27:0] product;
    reg [11:0] product_raw;
    reg product_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            delta_raw <= 12'd0;
            clamped_raw <= 12'd0;
            clamp_valid <= 1'b0;
            product <= 28'd0;
            product_raw <= 12'd0;
            product_valid <= 1'b0;
        end else if (frame_cancel) begin
            clamp_valid <= 0; product_valid <= 0;
        end else begin
            clamp_valid <= raw_valid;
            if (raw_valid) begin
                clamped_raw <= raw_data;
                if (raw_data <= RAW_MIN) delta_raw <= 12'd0;
                else if (raw_data >= RAW_MAX) delta_raw <= SPAN;
                else delta_raw <= raw_data - RAW_MIN;
            end
            product_valid <= clamp_valid;
            if (clamp_valid) begin
                product <= delta_raw * GAIN_SPAN;
                product_raw <= clamped_raw;
            end
        end
    end
    // product <= SPAN * GAIN_SPAN < SPAN * 65536. Its high 12 bits
    // are already a remainder smaller than SPAN; 16 quotient bits remain.
    // Each stage computes ONE quotient bit with a 14-bit subtract.
    wire [11:0] remainder_pipe [0:16];
    wire [15:0] quotient_pipe [0:16];
    wire [11:0] raw_pipe [0:16];
    wire [16:0] valid_pipe;
    assign remainder_pipe[0] = product[27:16];
    assign quotient_pipe[0] = product[15:0];
    assign raw_pipe[0] = product_raw;
    assign valid_pipe[0] = product_valid;
    genvar bit_index;
    generate
        for (bit_index=0; bit_index<16; bit_index=bit_index+1) begin: divide_bit
            wire [12:0] shifted_remainder;
            wire [13:0] difference;
            wire quotient_bit;
            reg [11:0] remainder_reg;
            reg [15:0] quotient_reg;
            reg [11:0] raw_reg;
            reg valid_reg;
            assign shifted_remainder = {remainder_pipe[bit_index],
                                         quotient_pipe[bit_index][15]};
            assign difference = {1'b0, shifted_remainder} - {2'b00, SPAN};
            assign quotient_bit = ~difference[13];
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    remainder_reg <= 12'd0;
                    quotient_reg <= 16'd0;
                    raw_reg <= 12'd0;
                    valid_reg <= 1'b0;
                end else if (frame_cancel) begin
                    valid_reg <= 0;
                end else begin
                    valid_reg <= valid_pipe[bit_index];
                    if (valid_pipe[bit_index]) begin
                        remainder_reg <= quotient_bit ? difference[11:0]
                                                       : shifted_remainder[11:0];
                        quotient_reg <= {quotient_pipe[bit_index][14:0],
                                         quotient_bit};
                        raw_reg <= raw_pipe[bit_index];
                    end
                end
            end
            assign remainder_pipe[bit_index+1] = remainder_reg;
            assign quotient_pipe[bit_index+1] = quotient_reg;
            assign raw_pipe[bit_index+1] = raw_reg;
            assign valid_pipe[bit_index+1] = valid_reg;
        end
    endgenerate
    reg [15:0] mapped;
    reg [11:0] mapped_raw;
    reg mapped_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mapped <= 16'd0;
            mapped_raw <= 12'd0;
            mapped_valid <= 1'b0;
        end else if (frame_cancel) begin
            mapped_valid <= 0;
        end else begin
            mapped_valid <= valid_pipe[16];
            if (valid_pipe[16]) begin
                mapped <= MIN_GAIN + quotient_pipe[16];
                mapped_raw <= raw_pipe[16];
            end
        end
    end
    // State changes only when a valid sample retires. This preserves the
    // original confirmation and signed Q16.8 smoothing for contiguous input.
    reg confirm_one;
    reg [23:0] smooth_q8;
    reg next_gate, next_confirm;
    reg [23:0] base_q8, next_q8;
    reg signed [24:0] delta, stepped;
    reg [15:0] gain_next;
    reg [24:0] rounded;
    always @* begin
        next_gate = gate;
        next_confirm = 1'b0;
        if ((!gate && mapped_raw >= TON) ||
            (gate && mapped_raw <= TOFF)) begin
            if (confirm_one) next_gate = ~gate;
            else next_confirm = 1'b1;
        end
        base_q8 = gate ? smooth_q8 : {MIN_GAIN, 8'd0};
        delta = $signed({1'b0, mapped, 8'd0}) - $signed({1'b0, base_q8});
        stepped = $signed({1'b0, base_q8}) + delta / 25'sd4;
        next_q8 = next_gate ? stepped[23:0] : 24'd0;
        rounded = {1'b0, next_q8} + 25'd128;
        gain_next = rounded[23:8];
        if (next_gate && gain_next < MIN_GAIN) gain_next = MIN_GAIN;
        if (!next_gate) gain_next = 16'd0;
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gate <= 1'b0;
            key_gain <= 16'd0;
            controls_valid <= 1'b0;
            confirm_one <= 1'b0;
            smooth_q8 <= 24'd0;
        end else if (frame_cancel) begin
            controls_valid <= 0; confirm_one <= 0;
        end else begin
            controls_valid <= mapped_valid;
            if (mapped_valid) begin
                gate <= next_gate;
                key_gain <= gain_next;
                confirm_one <= next_confirm;
                smooth_q8 <= next_q8;
            end
        end
    end
// synthesis translate_off

    initial begin
        if (TON <= TOFF || RAW_MAX <= RAW_MIN || MIN_GAIN == 0) begin
            $fatal(1, "Invalid pressure calibration parameters");
        end
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Eight-key interface, default first four enabled. Packed calibration: CH0 low.
// All inputs synchronous to clk. At acceptance edge E, sample the ENTIRE frame.
// Publish at E+19 (380 ns at 50 MHz), consumer accepts at E+20.
// One input frame per clock is supported; no busy/ready. Normal cadence is 1ms.
module pressure_frame_controls #(
    parameter integer ACTIVE_KEYS = 4,
    parameter [95:0] TON_PACK = {8{12'd256}},
    parameter [95:0] TOFF_PACK = {8{12'd128}},
    parameter [95:0] RAW_MIN_PACK = {8{12'd128}},
    parameter [95:0] RAW_MAX_PACK = {8{12'd3840}},
    parameter [127:0] MIN_GAIN_PACK = {8{16'd4096}}
)(
    input wire clk, rst_n,
    input wire [95:0] raw_frame,
    input wire frame_valid,
    input wire frame_cancel,
    output wire [7:0] gate,
    output wire [127:0] key_gain,
    output wire controls_valid,
    output reg [95:0] control_raw_frame
);
    wire [7:0] lane_gate, lane_valid;
    wire [127:0] lane_gain;
    reg [95:0] raw_pipe [0:18];
    reg [18:0] raw_valid_pipe;
    // Every enabled lane has the same fixed latency. Concatenation publishes
    // all independently registered lane results on the SAME clock edge.
    assign gate = lane_gate;
    assign key_gain = lane_gain;
    assign controls_valid = lane_valid[0];
    integer k;
    genvar i;
    generate for (i=0; i<8; i=i+1) begin: key_lane
        if (i < ACTIVE_KEYS) begin: enabled
            pressure_key_filter #(
                .TON(TON_PACK[12*i+:12]), .TOFF(TOFF_PACK[12*i+:12]),
                .RAW_MIN(RAW_MIN_PACK[12*i+:12]),
                .RAW_MAX(RAW_MAX_PACK[12*i+:12]),
                .MIN_GAIN(MIN_GAIN_PACK[16*i+:16])
            ) filter (
                .clk(clk), .rst_n(rst_n), .raw_data(raw_frame[12*i+:12]),
                .raw_valid(frame_valid), .frame_cancel(frame_cancel),
                .gate(lane_gate[i]), .key_gain(lane_gain[16*i+:16]),
                .controls_valid(lane_valid[i])
            );
        end else begin: disabled
            assign lane_gate[i] = 1'b0;
            assign lane_gain[16*i+:16] = 16'd0;
            assign lane_valid[i] = 1'b0;
        end
    end endgenerate

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            control_raw_frame <= 0; raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else if (frame_cancel) begin
            // No publication on a failed scan. Cancel pending samples without
            // losing the last complete outward control frame.
            raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else begin
            raw_pipe[0] <= raw_frame;
            for (k=1; k<19; k=k+1) raw_pipe[k] <= raw_pipe[k-1];
            raw_valid_pipe <= {raw_valid_pipe[17:0],frame_valid};
            if (raw_valid_pipe[18]) control_raw_frame <= raw_pipe[18];
        end
    end
// synthesis translate_off

    initial if (ACTIVE_KEYS != 1 && ACTIVE_KEYS != 4 && ACTIVE_KEYS != 8)
        $fatal(1, "ACTIVE_KEYS must be 1, 4 or 8");
    always @(posedge clk) if (rst_n && !frame_cancel) begin
        for (integer n=1; n<ACTIVE_KEYS; n=n+1)
            if (lane_valid[n] !== lane_valid[0])
                $fatal(1, "Per-key pipeline validity diverged");
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Integration EXAMPLE: synth_core should implement this same atomic latch rule.
// Outputs here are snapshots for each sample_ce, not synthesized audio.
module control_frame_receiver (
    input wire clk, rst_n,
    input wire [7:0] gate,
    input wire [127:0] key_gain,
    input wire controls_valid, sample_ce,
    output reg [7:0] sample_gate,
    output reg [127:0] sample_gain
);
    reg [7:0] held_gate;
    reg [127:0] held_gain;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            held_gate <= 0; held_gain <= 0;
            sample_gate <= 0; sample_gain <= 0;
        end else begin
            if (controls_valid) begin
                held_gate <= gate;
                held_gain <= key_gain;
            end
            if (sample_ce) begin
                sample_gate <= held_gate;
                sample_gain <= held_gain;
            end
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
module tb_frames #(
    parameter integer ACTIVE_KEYS=4,
    parameter [95:0] TON_PACK={8{12'd256}}, TOFF_PACK={8{12'd128}},
    parameter [95:0] RAW_MIN_PACK={8{12'd128}}, RAW_MAX_PACK={8{12'd3840}},
    parameter [127:0] MIN_GAIN_PACK={8{16'd4096}}
);
    reg clk=0, rst_n=0, frame_valid=0, frame_cancel=0, sample_ce=0;
    reg [95:0] raw_frame=0;
    always #10 clk=~clk;
    wire [7:0] gate,sample_gate;
    wire [127:0] key_gain,sample_gain;
    wire controls_valid;
    wire [95:0] control_raw_frame;
    pressure_frame_controls #(.ACTIVE_KEYS(ACTIVE_KEYS),.TON_PACK(TON_PACK),
        .TOFF_PACK(TOFF_PACK),.RAW_MIN_PACK(RAW_MIN_PACK),.RAW_MAX_PACK(RAW_MAX_PACK),
        .MIN_GAIN_PACK(MIN_GAIN_PACK)) dut(.*);
    control_frame_receiver receiver(.*);
    integer f,logfile,rc,n=0,reset_in,valid_in,cancel_in,ce_in,valid_expected;
    integer published=0,collisions=0;
    reg [7:0] gate_expected,sample_gate_expected;
    reg [127:0] gain_expected,sample_gain_expected;
    reg [95:0] raw_expected,raw_in;
    initial begin
        f=$fopen("vectors.txt","r"); logfile=$fopen("actual.csv","w");
        if(!f || !logfile) $fatal(1,"Cannot open vectors/log");
        $fdisplay(logfile,"cycle,valid,gate,gain,raw,sample_gate,sample_gain");
        $dumpfile("frames.vcd");
        $dumpvars(0,clk,rst_n,frame_valid,frame_cancel,raw_frame,gate,key_gain,
            controls_valid,control_raw_frame,sample_ce,sample_gate,sample_gain);
        while(!$feof(f)) begin
            rc=$fscanf(f,"%d %d %d %d %h %d %h %h %h %h %h\n",
                reset_in,valid_in,cancel_in,ce_in,raw_in,valid_expected,
                gate_expected,gain_expected,raw_expected,sample_gate_expected,sample_gain_expected);
            if(rc!=11) $fatal(1,"Bad vector %0d rc=%0d",n,rc);
            @(negedge clk);
            rst_n=reset_in; frame_valid=valid_in; frame_cancel=cancel_in;
            sample_ce=ce_in; raw_frame=raw_in;
            @(posedge clk);
            if(rst_n && controls_valid && sample_ce) collisions=collisions+1;
            #1;
            if(controls_valid!==valid_expected[0] || gate!==gate_expected ||
               key_gain!==gain_expected || control_raw_frame!==raw_expected ||
               sample_gate!==sample_gate_expected || sample_gain!==sample_gain_expected)
                $fatal(1,"Frame mismatch cycle=%0d got valid/gate/gain/raw=%b/%h/%h/%h expected=%b/%h/%h/%h sample=%h/%h expected=%h/%h",
                    n,controls_valid,gate,key_gain,control_raw_frame,
                    valid_expected[0],gate_expected,gain_expected,raw_expected,
                    sample_gate,sample_gain,sample_gate_expected,sample_gain_expected);
            if(controls_valid) published=published+1;
            $fdisplay(logfile,"%0d,%0d,%02h,%032h,%024h,%02h,%032h",n,controls_valid,
                gate,key_gain,control_raw_frame,sample_gate,sample_gain);
            n=n+1;
        end
        if(published<8000 || collisions<100) $fatal(1,"Insufficient coverage");
        $display("PASS ALL frames active=%0d cycles=%0d published=%0d old_frame_collisions=%0d",ACTIVE_KEYS,n,published,collisions);
        $fclose(f); $fclose(logfile); $finish;
    end
    initial begin #5000000; $fatal(1,"Frame test timeout"); end
endmodule
`default_nettype wire
module test; tb_frames #(.ACTIVE_KEYS(4),.TON_PACK(96'h100100100100100100100100),.TOFF_PACK(96'h80080080080080080080080),.RAW_MIN_PACK(96'h80080080080080080080080),.RAW_MAX_PACK(96'hf00f00f00f00f00f00f00f00),.MIN_GAIN_PACK(128'h10001000100010001000100010001000)) b(); endmodule
