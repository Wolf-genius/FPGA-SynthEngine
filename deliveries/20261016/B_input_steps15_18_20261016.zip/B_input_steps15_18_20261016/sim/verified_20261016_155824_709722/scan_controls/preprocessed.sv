`timescale 1ns/1ps
`default_nettype none

// One MCP3208 single-ended conversion. All registers use the 50 MHz clk.
// start/channel must already be synchronous to clk. Pulse start for one cycle;
// it is accepted only in IDLE. Busy-time pulses are discarded, not queued.
// A start held into the next IDLE is a new request (not an edge detector).
// channel is captured as part of the command when the request is accepted.
// After reset an early request is accepted, but CS waits for a 2 us high guard.
// data changes only on reset or valid; valid lasts one clk cycle, busy is then 0.
// This module does not schedule scans or publish an eight-channel control frame.
module adc_spi (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [2:0]  channel,
    input  wire        miso,
    output reg         cs_n,
    output reg         sclk,
    output reg         mosi,
    output reg         busy,
    output reg  [11:0] data,
    output reg         valid
);
    // Fixed project timing: 50 MHz / (2*50) = 500 kHz.
    // Separate counters/limits keep the 2 us gap from changing SPI frequency.
    localparam integer HALF_CYCLES = 50;
    localparam integer CS_HIGH_CYCLES = 100;
    localparam [2:0] IDLE = 3'd0, SHIFT = 3'd1,
                     HOLD = 3'd2, GAP = 3'd3, WAIT_HIGH = 3'd4;

    reg [2:0] state;
    reg [6:0] count; // Must represent 99 for the 100-cycle CS-high gap.
    reg [4:0] bit_index;
    reg [23:0] tx_shift;
    reg [11:0] rx_shift;
    reg miso_meta;
    reg miso_sync;

    // DOUT changes after the external falling SCLK edge. At 500 kHz the
    // 1 us half-cycle allows the modeled 200 ns DOUT delay plus this pipeline.
    // RTL simulation does not prove metastability MTBF or physical IO timing.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            miso_meta <= 1'b0;
            miso_sync <= 1'b0;
        end else begin
            miso_meta <= miso;
            miso_sync <= miso_meta;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            count <= 7'd0;
            bit_index <= 5'd0;
            tx_shift <= 24'd0;
            rx_shift <= 12'd0;
            cs_n <= 1'b1;
            sclk <= 1'b0;
            mosi <= 1'b0;
            busy <= 1'b0;
            data <= 12'd0;
            valid <= 1'b0;
        end else begin
            valid <= 1'b0;
            case (state)
                IDLE: begin
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    // Saturating reset-recovery guard. Normal GAP completion
                    // preloads 100, so it does not add a second normal gap.
                    // 101 observed edges span >=100 full periods even when
                    // reset deassertion is asynchronous to clk.
                    if (count < CS_HIGH_CYCLES)
                        count <= count + 7'd1;
                    if (start) begin
                        // [23:19]=0, [18]=Start, [17]=single-ended,
                        // [16:14]=channel. CH0=060000, CH1=064000.
                        tx_shift <= {5'b00000, 2'b11, channel, 14'd0};
                        rx_shift <= 12'd0;
                        bit_index <= 5'd0;
                        busy <= 1'b1;
                        if (count == CS_HIGH_CYCLES) begin
                            count <= 7'd0;
                            cs_n <= 1'b0;
                            state <= SHIFT;
                        end else begin
                            state <= WAIT_HIGH;
                        end
                    end
                end
                WAIT_HIGH: begin
                    if (count == CS_HIGH_CYCLES) begin
                        count <= 7'd0;
                        cs_n <= 1'b0;
                        state <= SHIFT;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                SHIFT: begin
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        if (!sclk) begin
                            sclk <= 1'b1;
                            // Zero-based 12..23 = rising edges 13..24.
                            // Ignore the unknown prefix and edge-12 null.
                            if (bit_index >= 5'd12)
                                rx_shift <= {rx_shift[10:0], miso_sync};
                        end else begin
                            sclk <= 1'b0;
                            if (bit_index == 5'd23) begin
                                state <= HOLD;
                            end else begin
                                mosi <= tx_shift[22];
                                tx_shift <= {tx_shift[22:0], 1'b0};
                                bit_index <= bit_index + 5'd1;
                            end
                        end
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                HOLD: begin
                    // Keep CS low for 1 us after the final falling SCLK edge.
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        cs_n <= 1'b1;
                        mosi <= 1'b0;
                        state <= GAP;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                GAP: begin
                    // Remain busy until CS has been high for 2 us.
                    // The earliest next acceptance adds another clk cycle.
                    if (count == CS_HIGH_CYCLES - 1) begin
                        count <= 7'd100;
                        data <= rx_shift; // B0 was captured earlier in SHIFT.
                        valid <= 1'b1;
                        busy <= 1'b0;
                        state <= IDLE;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                default: begin
                    state <= IDLE;
                    count <= 7'd0;
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    busy <= 1'b0;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Eight single-ended ADC reads per 1 ms. 50 MHz synchronous SPI-side handshake.
// Separate controller ports allow a stalled SPI handshake to be tested without
// forcing DUT internals. MISO alone cannot stall the existing fixed-length SPI.
module adc_scan_controller (
    input wire clk,
    input wire rst_n,
    input wire spi_busy,
    input wire spi_valid,
    input wire [11:0] spi_data,
    output reg spi_start,
    output reg [2:0] spi_channel,
    output reg spi_abort,
    output reg [95:0] raw_frame,
    output reg frame_valid,
    output reg scan_start,
    output reg scan_busy,
    output reg timeout,
    output reg [31:0] timeout_count
);
    localparam [1:0] IDLE = 2'd0, ISSUE = 2'd1, WAIT_RESULT = 2'd2;
    localparam [15:0] PERIOD_LAST = 16'd49999;
    reg [1:0] state;
    reg [15:0] period_count;
    reg [95:0] shadow_frame;
    wire period_tick = (period_count == PERIOD_LAST);

    // First attempt is on the 50,000th active clock after reset release.
    // The periodic grid never shifts with completion time or a timeout.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) period_count <= 16'd0;
        else if (period_tick) period_count <= 16'd0;
        else period_count <= period_count + 16'd1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            shadow_frame <= 96'd0;
            raw_frame <= 96'd0;
            spi_start <= 1'b0;
            spi_channel <= 3'd0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            scan_busy <= 1'b0;
            timeout <= 1'b0;
            timeout_count <= 32'd0;
        end else begin
            spi_start <= 1'b0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            timeout <= 1'b0;
            // Deadline wins over a coincident result, including CH7.
            // A failed round is discarded; do not start another on this tick.
            // Retry CH0 at the following 1 ms tick after the abort pulse.
            if (period_tick && state != IDLE) begin
                state <= IDLE;
                scan_busy <= 1'b0;
                shadow_frame <= 96'd0;
                spi_channel <= 3'd0;
                spi_abort <= 1'b1;
                timeout <= 1'b1;
                if (timeout_count != 32'hffffffff)
                    timeout_count <= timeout_count + 32'd1;
            end else begin
                case (state)
                    IDLE: begin
                        if (period_tick) begin
                            scan_start <= 1'b1;
                            scan_busy <= 1'b1;
                            shadow_frame <= 96'd0;
                            spi_channel <= 3'd0;
                            state <= ISSUE;
                        end
                    end
                    ISSUE: begin
                        if (!spi_busy) begin
                            spi_start <= 1'b1;
                            state <= WAIT_RESULT;
                        end
                    end
                    WAIT_RESULT: begin
                        if (spi_valid) begin
                            if (spi_channel == 3'd7) begin
                                // Include the CURRENT CH7 result; do not read
                                // an old shadow[95:84] on the same NBA edge.
                                raw_frame <= {spi_data, shadow_frame[83:0]};
                                frame_valid <= 1'b1;
                                scan_busy <= 1'b0;
                                state <= IDLE;
                            end else begin
                                shadow_frame[12*spi_channel +: 12] <= spi_data;
                                spi_channel <= spi_channel + 3'd1;
                                state <= ISSUE;
                            end
                        end
                    end
                    default: begin
                        state <= IDLE;
                        scan_busy <= 1'b0;
                        shadow_frame <= 96'd0;
                        spi_abort <= 1'b1;
                    end
                endcase
            end
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Synthesizable module wrapper, not a board top (no pin/LED/clock constraints).
// raw_frame[11:0]=CH0 ... raw_frame[95:84]=CH7, all 12-bit unsigned.
// frame_valid/scan_start/timeout are single clk pulses. raw_frame holds between
// publications, including timeouts; global reset clears it and all diagnostics.
// Raw ADC frames require later calibration/mapping before gate/key_gain use.
module adc_scan (
    input wire clk,
    input wire rst_n,
    input wire miso,
    output wire cs_n,
    output wire sclk,
    output wire mosi,
    output wire [95:0] raw_frame,
    output wire frame_valid,
    output wire scan_start,
    output wire scan_busy,
    output wire timeout,
    output wire [31:0] timeout_count
);
    wire spi_start, spi_busy, spi_valid, spi_abort;
    wire [2:0] spi_channel;
    wire [11:0] spi_data;
    // Controller abort resets only the SPI engine. Keep the last published raw
    // frame and timeout count. System top is responsible for global reset release.
    wire spi_rst_n = rst_n & ~spi_abort;
    adc_spi spi (.clk(clk), .rst_n(spi_rst_n), .start(spi_start),
        .channel(spi_channel), .miso(miso), .cs_n(cs_n), .sclk(sclk),
        .mosi(mosi), .busy(spi_busy), .data(spi_data), .valid(spi_valid));
    adc_scan_controller controller (.clk(clk), .rst_n(rst_n),
        .spi_busy(spi_busy), .spi_valid(spi_valid), .spi_data(spi_data),
        .spi_start(spi_start), .spi_channel(spi_channel), .spi_abort(spi_abort),
        .raw_frame(raw_frame), .frame_valid(frame_valid), .scan_start(scan_start),
        .scan_busy(scan_busy), .timeout(timeout), .timeout_count(timeout_count));
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Adapted from one_key/rtl/input/pressure_ch0_controls.v; arithmetic unchanged.
// Exact pressure mapping with registered multiply and restoring division.
// Accepts one raw sample per clock; publishes at acceptance edge E+19
// (380 ns at 50 MHz), with the same arithmetic as the source implementation.
module pressure_key_filter #(
    parameter [11:0] TON = 12'd256, TOFF = 12'd128,
    parameter [11:0] RAW_MIN = 12'd128, RAW_MAX = 12'd3840,
    parameter [15:0] MIN_GAIN = 16'd4096
)(
    input wire clk, rst_n,
    input wire [11:0] raw_data,
    input wire raw_valid,
    // Synchronous failed-round notification: flush pending work/confirmation;
    // preserve the last held state and smoothing history. Priority over raw_valid.
    input wire frame_cancel,
    output reg gate,
    output reg [15:0] key_gain,
    output reg controls_valid
);
    localparam [11:0] SPAN = RAW_MAX - RAW_MIN;
    localparam [15:0] GAIN_SPAN = 16'd65535 - MIN_GAIN;
    // Clamp and subtract before the registered multiply. The two endpoints
    // still map exactly to MIN_GAIN / 65535, including out-of-range inputs.
    reg [11:0] delta_raw, clamped_raw;
    reg clamp_valid;
    reg [27:0] product;
    reg [11:0] product_raw;
    reg product_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            delta_raw <= 12'd0;
            clamped_raw <= 12'd0;
            clamp_valid <= 1'b0;
            product <= 28'd0;
            product_raw <= 12'd0;
            product_valid <= 1'b0;
        end else if (frame_cancel) begin
            clamp_valid <= 0; product_valid <= 0;
        end else begin
            clamp_valid <= raw_valid;
            if (raw_valid) begin
                clamped_raw <= raw_data;
                if (raw_data <= RAW_MIN) delta_raw <= 12'd0;
                else if (raw_data >= RAW_MAX) delta_raw <= SPAN;
                else delta_raw <= raw_data - RAW_MIN;
            end
            product_valid <= clamp_valid;
            if (clamp_valid) begin
                product <= delta_raw * GAIN_SPAN;
                product_raw <= clamped_raw;
            end
        end
    end
    // product <= SPAN * GAIN_SPAN < SPAN * 65536. Its high 12 bits
    // are already a remainder smaller than SPAN; 16 quotient bits remain.
    // Each stage computes ONE quotient bit with a 14-bit subtract.
    wire [11:0] remainder_pipe [0:16];
    wire [15:0] quotient_pipe [0:16];
    wire [11:0] raw_pipe [0:16];
    wire [16:0] valid_pipe;
    assign remainder_pipe[0] = product[27:16];
    assign quotient_pipe[0] = product[15:0];
    assign raw_pipe[0] = product_raw;
    assign valid_pipe[0] = product_valid;
    genvar bit_index;
    generate
        for (bit_index=0; bit_index<16; bit_index=bit_index+1) begin: divide_bit
            wire [12:0] shifted_remainder;
            wire [13:0] difference;
            wire quotient_bit;
            reg [11:0] remainder_reg;
            reg [15:0] quotient_reg;
            reg [11:0] raw_reg;
            reg valid_reg;
            assign shifted_remainder = {remainder_pipe[bit_index],
                                         quotient_pipe[bit_index][15]};
            assign difference = {1'b0, shifted_remainder} - {2'b00, SPAN};
            assign quotient_bit = ~difference[13];
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    remainder_reg <= 12'd0;
                    quotient_reg <= 16'd0;
                    raw_reg <= 12'd0;
                    valid_reg <= 1'b0;
                end else if (frame_cancel) begin
                    valid_reg <= 0;
                end else begin
                    valid_reg <= valid_pipe[bit_index];
                    if (valid_pipe[bit_index]) begin
                        remainder_reg <= quotient_bit ? difference[11:0]
                                                       : shifted_remainder[11:0];
                        quotient_reg <= {quotient_pipe[bit_index][14:0],
                                         quotient_bit};
                        raw_reg <= raw_pipe[bit_index];
                    end
                end
            end
            assign remainder_pipe[bit_index+1] = remainder_reg;
            assign quotient_pipe[bit_index+1] = quotient_reg;
            assign raw_pipe[bit_index+1] = raw_reg;
            assign valid_pipe[bit_index+1] = valid_reg;
        end
    endgenerate
    reg [15:0] mapped;
    reg [11:0] mapped_raw;
    reg mapped_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mapped <= 16'd0;
            mapped_raw <= 12'd0;
            mapped_valid <= 1'b0;
        end else if (frame_cancel) begin
            mapped_valid <= 0;
        end else begin
            mapped_valid <= valid_pipe[16];
            if (valid_pipe[16]) begin
                mapped <= MIN_GAIN + quotient_pipe[16];
                mapped_raw <= raw_pipe[16];
            end
        end
    end
    // State changes only when a valid sample retires. This preserves the
    // original confirmation and signed Q16.8 smoothing for contiguous input.
    reg confirm_one;
    reg [23:0] smooth_q8;
    reg next_gate, next_confirm;
    reg [23:0] base_q8, next_q8;
    reg signed [24:0] delta, stepped;
    reg [15:0] gain_next;
    reg [24:0] rounded;
    always @* begin
        next_gate = gate;
        next_confirm = 1'b0;
        if ((!gate && mapped_raw >= TON) ||
            (gate && mapped_raw <= TOFF)) begin
            if (confirm_one) next_gate = ~gate;
            else next_confirm = 1'b1;
        end
        base_q8 = gate ? smooth_q8 : {MIN_GAIN, 8'd0};
        delta = $signed({1'b0, mapped, 8'd0}) - $signed({1'b0, base_q8});
        stepped = $signed({1'b0, base_q8}) + delta / 25'sd4;
        next_q8 = next_gate ? stepped[23:0] : 24'd0;
        rounded = {1'b0, next_q8} + 25'd128;
        gain_next = rounded[23:8];
        if (next_gate && gain_next < MIN_GAIN) gain_next = MIN_GAIN;
        if (!next_gate) gain_next = 16'd0;
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gate <= 1'b0;
            key_gain <= 16'd0;
            controls_valid <= 1'b0;
            confirm_one <= 1'b0;
            smooth_q8 <= 24'd0;
        end else if (frame_cancel) begin
            controls_valid <= 0; confirm_one <= 0;
        end else begin
            controls_valid <= mapped_valid;
            if (mapped_valid) begin
                gate <= next_gate;
                key_gain <= gain_next;
                confirm_one <= next_confirm;
                smooth_q8 <= next_q8;
            end
        end
    end
// synthesis translate_off

    initial begin
        if (TON <= TOFF || RAW_MAX <= RAW_MIN || MIN_GAIN == 0) begin
            $fatal(1, "Invalid pressure calibration parameters");
        end
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Eight-key interface, default first four enabled. Packed calibration: CH0 low.
// All inputs synchronous to clk. At acceptance edge E, sample the ENTIRE frame.
// Publish at E+19 (380 ns at 50 MHz), consumer accepts at E+20.
// One input frame per clock is supported; no busy/ready. Normal cadence is 1ms.
module pressure_frame_controls #(
    parameter integer ACTIVE_KEYS = 4,
    parameter [95:0] TON_PACK = {8{12'd256}},
    parameter [95:0] TOFF_PACK = {8{12'd128}},
    parameter [95:0] RAW_MIN_PACK = {8{12'd128}},
    parameter [95:0] RAW_MAX_PACK = {8{12'd3840}},
    parameter [127:0] MIN_GAIN_PACK = {8{16'd4096}}
)(
    input wire clk, rst_n,
    input wire [95:0] raw_frame,
    input wire frame_valid,
    input wire frame_cancel,
    output wire [7:0] gate,
    output wire [127:0] key_gain,
    output wire controls_valid,
    output reg [95:0] control_raw_frame
);
    wire [7:0] lane_gate, lane_valid;
    wire [127:0] lane_gain;
    reg [95:0] raw_pipe [0:18];
    reg [18:0] raw_valid_pipe;
    // Every enabled lane has the same fixed latency. Concatenation publishes
    // all independently registered lane results on the SAME clock edge.
    assign gate = lane_gate;
    assign key_gain = lane_gain;
    assign controls_valid = lane_valid[0];
    integer k;
    genvar i;
    generate for (i=0; i<8; i=i+1) begin: key_lane
        if (i < ACTIVE_KEYS) begin: enabled
            pressure_key_filter #(
                .TON(TON_PACK[12*i+:12]), .TOFF(TOFF_PACK[12*i+:12]),
                .RAW_MIN(RAW_MIN_PACK[12*i+:12]),
                .RAW_MAX(RAW_MAX_PACK[12*i+:12]),
                .MIN_GAIN(MIN_GAIN_PACK[16*i+:16])
            ) filter (
                .clk(clk), .rst_n(rst_n), .raw_data(raw_frame[12*i+:12]),
                .raw_valid(frame_valid), .frame_cancel(frame_cancel),
                .gate(lane_gate[i]), .key_gain(lane_gain[16*i+:16]),
                .controls_valid(lane_valid[i])
            );
        end else begin: disabled
            assign lane_gate[i] = 1'b0;
            assign lane_gain[16*i+:16] = 16'd0;
            assign lane_valid[i] = 1'b0;
        end
    end endgenerate

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            control_raw_frame <= 0; raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else if (frame_cancel) begin
            // No publication on a failed scan. Cancel pending samples without
            // losing the last complete outward control frame.
            raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else begin
            raw_pipe[0] <= raw_frame;
            for (k=1; k<19; k=k+1) raw_pipe[k] <= raw_pipe[k-1];
            raw_valid_pipe <= {raw_valid_pipe[17:0],frame_valid};
            if (raw_valid_pipe[18]) control_raw_frame <= raw_pipe[18];
        end
    end
// synthesis translate_off

    initial if (ACTIVE_KEYS != 1 && ACTIVE_KEYS != 4 && ACTIVE_KEYS != 8)
        $fatal(1, "ACTIVE_KEYS must be 1, 4 or 8");
    always @(posedge clk) if (rst_n && !frame_cancel) begin
        for (integer n=1; n<ACTIVE_KEYS; n=n+1)
            if (lane_valid[n] !== lane_valid[0])
                $fatal(1, "Per-key pipeline validity diverged");
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// B delivery module, NOT a board top. A owns reset release, CST/SDC and audio.
// Existing scanner/SPI timing and timeout semantics are preserved verbatim.
module pressure_keys_input #(
    parameter integer ACTIVE_KEYS = 4,
    parameter [95:0] TON_PACK = {8{12'd256}},
    parameter [95:0] TOFF_PACK = {8{12'd128}},
    parameter [95:0] RAW_MIN_PACK = {8{12'd128}},
    parameter [95:0] RAW_MAX_PACK = {8{12'd3840}},
    parameter [127:0] MIN_GAIN_PACK = {8{16'd4096}}
)(
    input wire clk, rst_n, miso,
    output wire cs_n, sclk, mosi,
    output wire [7:0] gate,
    output wire [127:0] key_gain,
    output wire controls_valid,
    output wire [95:0] raw_frame,
    output wire frame_valid, scan_start, scan_busy, timeout,
    output wire [31:0] timeout_count,
    output wire [95:0] control_raw_frame
);
    adc_scan scan (
        .clk(clk), .rst_n(rst_n), .miso(miso),
        .cs_n(cs_n), .sclk(sclk), .mosi(mosi),
        .raw_frame(raw_frame), .frame_valid(frame_valid),
        .scan_start(scan_start), .scan_busy(scan_busy),
        .timeout(timeout), .timeout_count(timeout_count)
    );
    pressure_frame_controls #(
        .ACTIVE_KEYS(ACTIVE_KEYS), .TON_PACK(TON_PACK), .TOFF_PACK(TOFF_PACK),
        .RAW_MIN_PACK(RAW_MIN_PACK), .RAW_MAX_PACK(RAW_MAX_PACK),
        .MIN_GAIN_PACK(MIN_GAIN_PACK)
    ) controls (
        .clk(clk), .rst_n(rst_n), .raw_frame(raw_frame),
        .frame_valid(frame_valid), .frame_cancel(timeout),
        .gate(gate), .key_gain(key_gain), .controls_valid(controls_valid),
        .control_raw_frame(control_raw_frame)
    );
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none

// Behavioral digital protocol model, not an analog converter model.
// Only the external SPI pins select the channel. No DUT hierarchy is used.
// Search for Start, then decode SGL and D2..D0 relative to that Start.
module mcp3208_model (
    input wire rst_n,
    input wire cs_n,
    input wire sclk,
    input wire mosi,
    input wire [95:0] channel_values,
    input integer dout_delay_ns,
    output reg miso,
    output reg [2:0] decoded_channel,
    output reg [11:0] selected_value,
    output reg [23:0] command_seen,
    output integer rise_count,
    output integer start_edge
);
    reg started;
    integer after_start;
    integer frame_id = 0;
    integer scheduled_frame;
    reg scheduled_bit;

    initial miso = 1'bx;

    always @(negedge cs_n) begin
        frame_id = frame_id + 1;
        rise_count = 0;
        start_edge = 0;
        after_start = 0;
        started = 0;
        decoded_channel = 0;
        selected_value = 12'hxxx;
        command_seen = 0;
        miso = 1'bx;
    end

    always @(posedge sclk) begin
        if (rst_n && !cs_n) begin
            rise_count = rise_count + 1;
            command_seen = {command_seen[22:0], mosi};
            if (!started) begin
                if (mosi === 1'b1) begin
                    started = 1;
                    start_edge = rise_count;
                    after_start = 0;
                end else if (mosi !== 1'b0)
                    $fatal(1, "MODEL unknown DIN before Start");
            end else begin
                after_start = after_start + 1;
                case (after_start)
                    1: if (mosi !== 1'b1)
                           $fatal(1, "MODEL expected single-ended SGL=1");
                    2: decoded_channel[2] = mosi;
                    3: decoded_channel[1] = mosi;
                    4: begin
                        decoded_channel[0] = mosi;
                        if (^decoded_channel === 1'bx)
                            $fatal(1, "MODEL unknown channel bits");
                        selected_value = channel_values[12*decoded_channel +: 12];
                    end
                endcase
            end
        end
    end

    always @(negedge sclk) begin
        if (rst_n && !cs_n) begin
            scheduled_frame = frame_id;
            if (started && after_start == 5)
                scheduled_bit = 1'b0; // Null, received on the next rising edge.
            else if (started && after_start >= 6 && after_start <= 17)
                scheduled_bit = selected_value[17-after_start];
            else
                scheduled_bit = 1'bx;
            #(dout_delay_ns);
            if (rst_n && !cs_n && frame_id == scheduled_frame)
                miso = scheduled_bit;
        end
    end

    always @(posedge cs_n or negedge rst_n)
        miso = 1'bx;
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
module tb_scan_controls;
    reg clk=0,rst_n=0;
    always #10 clk=~clk;
    wire cs_n,sclk,mosi,miso,frame_valid,scan_start,scan_busy,timeout,controls_valid;
    wire [95:0] raw_frame,control_raw_frame;
    wire [7:0] gate;
    wire [127:0] key_gain;
    wire [31:0] timeout_count;
    reg [95:0] channel_values=0;
    integer dout_delay_ns=200;
    wire [2:0] decoded_channel;
    wire [11:0] selected_value;
    wire [23:0] command_seen;
    wire signed [31:0] model_rises,model_start_edge;
    pressure_keys_input dut(.*);
    mcp3208_model adc(.rst_n(rst_n),.cs_n(cs_n),.sclk(sclk),.mosi(mosi),
        .channel_values(channel_values),.dout_delay_ns(dout_delay_ns),.miso(miso),
        .decoded_channel(decoded_channel),.selected_value(selected_value),
        .command_seen(command_seen),.rise_count(model_rises),.start_edge(model_start_edge));
    integer rounds=0,frames=0,controls=0,ch=0,rises=0,falls=0,transactions=0,aborts=0,atomic_checks=0;
    integer logfile,epoch=0,cycle=0,pending_cycle=-1;
    reg active=0;
    reg [95:0] expected=0;
    reg [7:0] held_gate=0;
    reg [127:0] held_gain=0;
    reg [23:0] tx;
    reg [11:0] rx;
    time last_start=0,round_start=0,last_edge=0,last_end=0,cs_start=0,last_fall=0;
    time last_mosi=0,last_rise=0,pulse=0;
    always @(posedge clk) cycle=cycle+1;
    always @(posedge scan_start) begin
        if(last_start && $time-last_start!=1000000) $fatal(1,"Not 1ms scan");
        last_start=$time; round_start=$time; rounds=rounds+1; ch=0;
        // Directed real-pin ADC stimuli, fixed for an entire scan.
        case(rounds)
            1: channel_values={4{24'hfff000}};
            2,3: channel_values={12'hfff,12'haaa,12'h555,12'habc,12'd3200,12'd2400,12'd1600,12'd800};
            4,5: channel_values={12'hfff,12'hfff,12'hfff,12'hfff,12'd3200,12'd2400,12'd0,12'd800};
            6,7: channel_values={12'hfff,12'hfff,12'hfff,12'hfff,12'd3200,12'd400,12'd1600,12'd800};
            8,9: channel_values={12'hfff,12'hfff,12'hfff,12'hfff,12'd3200,12'd3600,12'd1600,12'd800};
            10,11: channel_values=0;
            default: channel_values={8{12'd3000}};
        endcase
        expected=channel_values; held_gate=gate; held_gain=key_gain;
        $fdisplay(logfile,"SCAN,%0d,%0d,%0d,%024h,%02h,%032h",epoch,cycle,$time,expected,gate,key_gain);
    end
    always @(mosi) begin
        if(rst_n && active && (sclk || (last_rise && $time-last_rise<50)))
            $fatal(1,"MOSI hold/edge");
        last_mosi=$time;
    end
    always @(negedge cs_n) if(rst_n) begin
        if(active || ch>7 || (last_end && $time-last_end<2000)) $fatal(1,"CS overlap/gap");
        active=1; rises=0; falls=0; tx=0; rx=0; cs_start=$time; last_edge=0; last_rise=0;
        if(ch==4) begin
            if(gate!==held_gate || key_gain!==held_gain) $fatal(1,"Partial controls visible at CH4");
            atomic_checks=atomic_checks+1;
        end
    end
    always @(sclk) if(rst_n && active) begin
        if(last_edge && $time-last_edge!=1000) $fatal(1,"SPI half period");
        last_edge=$time;
        if(sclk) begin
            rises=rises+1; tx={tx[22:0],mosi}; last_rise=$time;
            if($time-last_mosi<50 || (rises==1 && $time-cs_start!=1000)) $fatal(1,"SPI setup");
            if(rises<=11 && miso!==1'bx) $fatal(1,"Unknown prefix missing");
            if(rises==12 && miso!==1'b0) $fatal(1,"Null missing");
            if(rises>=13) rx={rx[10:0],miso};
        end else begin falls=falls+1; last_fall=$time; end
    end
    always @(posedge cs_n) if(active) begin
        if(rst_n) begin
            if(rises!=24 || falls!=24 || sclk || $time-last_fall!=1000 ||
                tx!==(24'h060000 | ({21'd0,ch[2:0]}<<14)) || decoded_channel!==ch[2:0] ||
                model_start_edge!=6 || rx!==expected[12*ch+:12]) $fatal(1,"SPI command/data/timing");
            ch=ch+1; transactions=transactions+1;
        end else aborts=aborts+1;
        last_end=$time; active=0;
    end
    always @(posedge frame_valid) begin
        if(ch!=8 || raw_frame!==expected || $time-round_start>=1000000) $fatal(1,"Raw frame mismatch");
        frames=frames+1; pending_cycle=cycle;
        $fdisplay(logfile,"RAW,%0d,%0d,%0d,%024h,%02h,%032h",epoch,cycle,$time,raw_frame,gate,key_gain);
    end
    always @(posedge controls_valid) begin
        if(cycle-pending_cycle!=20 || control_raw_frame!==expected || gate[7:4]!==0 || key_gain[127:64]!==0)
            $fatal(1,"Control frame latency/packing");
        controls=controls+1; pulse=$time;
        $fdisplay(logfile,"CONTROL,%0d,%0d,%0d,%024h,%02h,%032h",epoch,cycle,$time,control_raw_frame,gate,key_gain);
    end
    always @(negedge controls_valid) if(rst_n && pulse && $time-pulse!=20) $fatal(1,"valid pulse width");
    always @(gate,key_gain,control_raw_frame) begin
        #1;
        if(rst_n && !controls_valid) $fatal(1,"Control changed without valid");
    end
    always @(posedge timeout) $fatal(1,"Unexpected scan timeout");
    initial begin
        logfile=$fopen("integrated.csv","w");
        $fdisplay(logfile,"event,epoch,cycle,time_ns,raw,gate,gain");
        $dumpfile("integrated.vcd");
        $dumpvars(0,rst_n,cs_n,sclk,mosi,miso,channel_values,raw_frame,frame_valid,
            scan_start,scan_busy,timeout,timeout_count,gate,key_gain,controls_valid,control_raw_frame);
        repeat(5) @(negedge clk); rst_n=1;
        wait(controls==11);
        // Reset in the next scan CH4. No half-frame or phantom controls.
        wait(active && ch==4 && rises==7); #3; rst_n=0; epoch=1; last_start=0; pending_cycle=-1;
        #1; if(gate!==0 || key_gain!==0 || controls_valid || control_raw_frame!==0) $fatal(1,"Reset not silent");
        #20; rst_n=1;
        wait(controls==14); repeat(5) @(negedge clk);
        if(controls!=frames || aborts!=1 || timeout_count!=0 || atomic_checks!=15)
            $fatal(1,"Integrated final counts");
        $display("PASS ALL scan_controls frames=%0d controls=%0d transactions=%0d reset_aborts=%0d atomic_CH4=%0d",frames,controls,transactions,aborts,atomic_checks);
        $fclose(logfile); $finish;
    end
    initial begin #20000000; $fatal(1,"Integration timeout"); end
endmodule
`default_nettype wire
