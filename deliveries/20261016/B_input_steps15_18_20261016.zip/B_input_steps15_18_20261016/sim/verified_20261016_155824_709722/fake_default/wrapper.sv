module test; tb_fake_controls #(.FRAME_CYCLES(50000),.TOTAL_FRAMES(12)) b(); endmodule
