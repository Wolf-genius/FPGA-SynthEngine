module test; tb_fake_controls #(.FRAME_CYCLES(40),.TOTAL_FRAMES(802)) b(); endmodule
