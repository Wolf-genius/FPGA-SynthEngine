module probe; initial $finish; endmodule
