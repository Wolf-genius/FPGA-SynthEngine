module test; pressure_frame_controls #(.ACTIVE_KEYS(0)) dut(.clk(1'b0),.rst_n(1'b0),.raw_frame(96'd0),.frame_valid(1'b0),.frame_cancel(1'b0)); endmodule
