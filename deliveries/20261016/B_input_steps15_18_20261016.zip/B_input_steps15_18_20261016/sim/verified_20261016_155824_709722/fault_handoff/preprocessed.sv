`timescale 1ns/1ps
`default_nettype none
// Eight single-ended ADC reads per 1 ms. 50 MHz synchronous SPI-side handshake.
// Separate controller ports allow a stalled SPI handshake to be tested without
// forcing DUT internals. MISO alone cannot stall the existing fixed-length SPI.
module adc_scan_controller (
    input wire clk,
    input wire rst_n,
    input wire spi_busy,
    input wire spi_valid,
    input wire [11:0] spi_data,
    output reg spi_start,
    output reg [2:0] spi_channel,
    output reg spi_abort,
    output reg [95:0] raw_frame,
    output reg frame_valid,
    output reg scan_start,
    output reg scan_busy,
    output reg timeout,
    output reg [31:0] timeout_count
);
    localparam [1:0] IDLE = 2'd0, ISSUE = 2'd1, WAIT_RESULT = 2'd2;
    localparam [15:0] PERIOD_LAST = 16'd49999;
    reg [1:0] state;
    reg [15:0] period_count;
    reg [95:0] shadow_frame;
    wire period_tick = (period_count == PERIOD_LAST);

    // First attempt is on the 50,000th active clock after reset release.
    // The periodic grid never shifts with completion time or a timeout.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) period_count <= 16'd0;
        else if (period_tick) period_count <= 16'd0;
        else period_count <= period_count + 16'd1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            shadow_frame <= 96'd0;
            raw_frame <= 96'd0;
            spi_start <= 1'b0;
            spi_channel <= 3'd0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            scan_busy <= 1'b0;
            timeout <= 1'b0;
            timeout_count <= 32'd0;
        end else begin
            spi_start <= 1'b0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            timeout <= 1'b0;
            // Deadline wins over a coincident result, including CH7.
            // A failed round is discarded; do not start another on this tick.
            // Retry CH0 at the following 1 ms tick after the abort pulse.
            if (period_tick && state != IDLE) begin
                state <= IDLE;
                scan_busy <= 1'b0;
                shadow_frame <= 96'd0;
                spi_channel <= 3'd0;
                spi_abort <= 1'b1;
                timeout <= 1'b1;
                if (timeout_count != 32'hffffffff)
                    timeout_count <= timeout_count + 32'd1;
            end else begin
                case (state)
                    IDLE: begin
                        if (period_tick) begin
                            scan_start <= 1'b1;
                            scan_busy <= 1'b1;
                            shadow_frame <= 96'd0;
                            spi_channel <= 3'd0;
                            state <= ISSUE;
                        end
                    end
                    ISSUE: begin
                        if (!spi_busy) begin
                            spi_start <= 1'b1;
                            state <= WAIT_RESULT;
                        end
                    end
                    WAIT_RESULT: begin
                        if (spi_valid) begin
                            if (spi_channel == 3'd7) begin
                                // Include the CURRENT CH7 result; do not read
                                // an old shadow[95:84] on the same NBA edge.
                                raw_frame <= {spi_data, shadow_frame[83:0]};
                                frame_valid <= 1'b1;
                                scan_busy <= 1'b0;
                                state <= IDLE;
                            end else begin
                                shadow_frame[12*spi_channel +: 12] <= spi_data;
                                spi_channel <= spi_channel + 3'd1;
                                state <= ISSUE;
                            end
                        end
                    end
                    default: begin
                        state <= IDLE;
                        scan_busy <= 1'b0;
                        shadow_frame <= 96'd0;
                        spi_abort <= 1'b1;
                    end
                endcase
            end
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Adapted from one_key/rtl/input/pressure_ch0_controls.v; arithmetic unchanged.
// Exact pressure mapping with registered multiply and restoring division.
// Accepts one raw sample per clock; publishes at acceptance edge E+19
// (380 ns at 50 MHz), with the same arithmetic as the source implementation.
module pressure_key_filter #(
    parameter [11:0] TON = 12'd256, TOFF = 12'd128,
    parameter [11:0] RAW_MIN = 12'd128, RAW_MAX = 12'd3840,
    parameter [15:0] MIN_GAIN = 16'd4096
)(
    input wire clk, rst_n,
    input wire [11:0] raw_data,
    input wire raw_valid,
    // Synchronous failed-round notification: flush pending work/confirmation;
    // preserve the last held state and smoothing history. Priority over raw_valid.
    input wire frame_cancel,
    output reg gate,
    output reg [15:0] key_gain,
    output reg controls_valid
);
    localparam [11:0] SPAN = RAW_MAX - RAW_MIN;
    localparam [15:0] GAIN_SPAN = 16'd65535 - MIN_GAIN;
    // Clamp and subtract before the registered multiply. The two endpoints
    // still map exactly to MIN_GAIN / 65535, including out-of-range inputs.
    reg [11:0] delta_raw, clamped_raw;
    reg clamp_valid;
    reg [27:0] product;
    reg [11:0] product_raw;
    reg product_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            delta_raw <= 12'd0;
            clamped_raw <= 12'd0;
            clamp_valid <= 1'b0;
            product <= 28'd0;
            product_raw <= 12'd0;
            product_valid <= 1'b0;
        end else if (frame_cancel) begin
            clamp_valid <= 0; product_valid <= 0;
        end else begin
            clamp_valid <= raw_valid;
            if (raw_valid) begin
                clamped_raw <= raw_data;
                if (raw_data <= RAW_MIN) delta_raw <= 12'd0;
                else if (raw_data >= RAW_MAX) delta_raw <= SPAN;
                else delta_raw <= raw_data - RAW_MIN;
            end
            product_valid <= clamp_valid;
            if (clamp_valid) begin
                product <= delta_raw * GAIN_SPAN;
                product_raw <= clamped_raw;
            end
        end
    end
    // product <= SPAN * GAIN_SPAN < SPAN * 65536. Its high 12 bits
    // are already a remainder smaller than SPAN; 16 quotient bits remain.
    // Each stage computes ONE quotient bit with a 14-bit subtract.
    wire [11:0] remainder_pipe [0:16];
    wire [15:0] quotient_pipe [0:16];
    wire [11:0] raw_pipe [0:16];
    wire [16:0] valid_pipe;
    assign remainder_pipe[0] = product[27:16];
    assign quotient_pipe[0] = product[15:0];
    assign raw_pipe[0] = product_raw;
    assign valid_pipe[0] = product_valid;
    genvar bit_index;
    generate
        for (bit_index=0; bit_index<16; bit_index=bit_index+1) begin: divide_bit
            wire [12:0] shifted_remainder;
            wire [13:0] difference;
            wire quotient_bit;
            reg [11:0] remainder_reg;
            reg [15:0] quotient_reg;
            reg [11:0] raw_reg;
            reg valid_reg;
            assign shifted_remainder = {remainder_pipe[bit_index],
                                         quotient_pipe[bit_index][15]};
            assign difference = {1'b0, shifted_remainder} - {2'b00, SPAN};
            assign quotient_bit = ~difference[13];
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    remainder_reg <= 12'd0;
                    quotient_reg <= 16'd0;
                    raw_reg <= 12'd0;
                    valid_reg <= 1'b0;
                end else if (frame_cancel) begin
                    valid_reg <= 0;
                end else begin
                    valid_reg <= valid_pipe[bit_index];
                    if (valid_pipe[bit_index]) begin
                        remainder_reg <= quotient_bit ? difference[11:0]
                                                       : shifted_remainder[11:0];
                        quotient_reg <= {quotient_pipe[bit_index][14:0],
                                         quotient_bit};
                        raw_reg <= raw_pipe[bit_index];
                    end
                end
            end
            assign remainder_pipe[bit_index+1] = remainder_reg;
            assign quotient_pipe[bit_index+1] = quotient_reg;
            assign raw_pipe[bit_index+1] = raw_reg;
            assign valid_pipe[bit_index+1] = valid_reg;
        end
    endgenerate
    reg [15:0] mapped;
    reg [11:0] mapped_raw;
    reg mapped_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mapped <= 16'd0;
            mapped_raw <= 12'd0;
            mapped_valid <= 1'b0;
        end else if (frame_cancel) begin
            mapped_valid <= 0;
        end else begin
            mapped_valid <= valid_pipe[16];
            if (valid_pipe[16]) begin
                mapped <= MIN_GAIN + quotient_pipe[16];
                mapped_raw <= raw_pipe[16];
            end
        end
    end
    // State changes only when a valid sample retires. This preserves the
    // original confirmation and signed Q16.8 smoothing for contiguous input.
    reg confirm_one;
    reg [23:0] smooth_q8;
    reg next_gate, next_confirm;
    reg [23:0] base_q8, next_q8;
    reg signed [24:0] delta, stepped;
    reg [15:0] gain_next;
    reg [24:0] rounded;
    always @* begin
        next_gate = gate;
        next_confirm = 1'b0;
        if ((!gate && mapped_raw >= TON) ||
            (gate && mapped_raw <= TOFF)) begin
            if (confirm_one) next_gate = ~gate;
            else next_confirm = 1'b1;
        end
        base_q8 = gate ? smooth_q8 : {MIN_GAIN, 8'd0};
        delta = $signed({1'b0, mapped, 8'd0}) - $signed({1'b0, base_q8});
        stepped = $signed({1'b0, base_q8}) + delta / 25'sd4;
        next_q8 = next_gate ? stepped[23:0] : 24'd0;
        rounded = {1'b0, next_q8} + 25'd128;
        gain_next = rounded[23:8];
        if (next_gate && gain_next < MIN_GAIN) gain_next = MIN_GAIN;
        if (!next_gate) gain_next = 16'd0;
    end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gate <= 1'b0;
            key_gain <= 16'd0;
            controls_valid <= 1'b0;
            confirm_one <= 1'b0;
            smooth_q8 <= 24'd0;
        end else if (frame_cancel) begin
            controls_valid <= 0; confirm_one <= 0;
        end else begin
            controls_valid <= mapped_valid;
            if (mapped_valid) begin
                gate <= next_gate;
                key_gain <= gain_next;
                confirm_one <= next_confirm;
                smooth_q8 <= next_q8;
            end
        end
    end
// synthesis translate_off

    initial begin
        if (TON <= TOFF || RAW_MAX <= RAW_MIN || MIN_GAIN == 0) begin
            $fatal(1, "Invalid pressure calibration parameters");
        end
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Eight-key interface, default first four enabled. Packed calibration: CH0 low.
// All inputs synchronous to clk. At acceptance edge E, sample the ENTIRE frame.
// Publish at E+19 (380 ns at 50 MHz), consumer accepts at E+20.
// One input frame per clock is supported; no busy/ready. Normal cadence is 1ms.
module pressure_frame_controls #(
    parameter integer ACTIVE_KEYS = 4,
    parameter [95:0] TON_PACK = {8{12'd256}},
    parameter [95:0] TOFF_PACK = {8{12'd128}},
    parameter [95:0] RAW_MIN_PACK = {8{12'd128}},
    parameter [95:0] RAW_MAX_PACK = {8{12'd3840}},
    parameter [127:0] MIN_GAIN_PACK = {8{16'd4096}}
)(
    input wire clk, rst_n,
    input wire [95:0] raw_frame,
    input wire frame_valid,
    input wire frame_cancel,
    output wire [7:0] gate,
    output wire [127:0] key_gain,
    output wire controls_valid,
    output reg [95:0] control_raw_frame
);
    wire [7:0] lane_gate, lane_valid;
    wire [127:0] lane_gain;
    reg [95:0] raw_pipe [0:18];
    reg [18:0] raw_valid_pipe;
    // Every enabled lane has the same fixed latency. Concatenation publishes
    // all independently registered lane results on the SAME clock edge.
    assign gate = lane_gate;
    assign key_gain = lane_gain;
    assign controls_valid = lane_valid[0];
    integer k;
    genvar i;
    generate for (i=0; i<8; i=i+1) begin: key_lane
        if (i < ACTIVE_KEYS) begin: enabled
            pressure_key_filter #(
                .TON(TON_PACK[12*i+:12]), .TOFF(TOFF_PACK[12*i+:12]),
                .RAW_MIN(RAW_MIN_PACK[12*i+:12]),
                .RAW_MAX(RAW_MAX_PACK[12*i+:12]),
                .MIN_GAIN(MIN_GAIN_PACK[16*i+:16])
            ) filter (
                .clk(clk), .rst_n(rst_n), .raw_data(raw_frame[12*i+:12]),
                .raw_valid(frame_valid), .frame_cancel(frame_cancel),
                .gate(lane_gate[i]), .key_gain(lane_gain[16*i+:16]),
                .controls_valid(lane_valid[i])
            );
        end else begin: disabled
            assign lane_gate[i] = 1'b0;
            assign lane_gain[16*i+:16] = 16'd0;
            assign lane_valid[i] = 1'b0;
        end
    end endgenerate

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            control_raw_frame <= 0; raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else if (frame_cancel) begin
            // No publication on a failed scan. Cancel pending samples without
            // losing the last complete outward control frame.
            raw_valid_pipe <= 0;
            for (k=0; k<19; k=k+1) raw_pipe[k] <= 0;
        end else begin
            raw_pipe[0] <= raw_frame;
            for (k=1; k<19; k=k+1) raw_pipe[k] <= raw_pipe[k-1];
            raw_valid_pipe <= {raw_valid_pipe[17:0],frame_valid};
            if (raw_valid_pipe[18]) control_raw_frame <= raw_pipe[18];
        end
    end
// synthesis translate_off

    initial if (ACTIVE_KEYS != 1 && ACTIVE_KEYS != 4 && ACTIVE_KEYS != 8)
        $fatal(1, "ACTIVE_KEYS must be 1, 4 or 8");
    always @(posedge clk) if (rst_n && !frame_cancel) begin
        for (integer n=1; n<ACTIVE_KEYS; n=n+1)
            if (lane_valid[n] !== lane_valid[0])
                $fatal(1, "Per-key pipeline validity diverged");
    end

// synthesis translate_on
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Inject faults at the PUBLIC controller handshake, never force DUT internals.
module tb_fault_handoff;
    reg clk=0,rst_n=0,spi_busy=0,spi_valid=0;
    reg [11:0] spi_data=0;
    always #10 clk=~clk;
    wire spi_start,spi_abort,frame_valid,scan_start,scan_busy,timeout,controls_valid;
    wire [2:0] spi_channel;
    wire [95:0] raw_frame,control_raw_frame;
    wire [31:0] timeout_count;
    wire [7:0] gate;
    wire [127:0] key_gain;
    adc_scan_controller scanner(.*);
    pressure_frame_controls controls(.clk(clk),.rst_n(rst_n),.raw_frame(raw_frame),
        .frame_valid(frame_valid),.frame_cancel(timeout),.gate(gate),.key_gain(key_gain),
        .controls_valid(controls_valid),.control_raw_frame(control_raw_frame));
    integer frames=0,errors=0,k,rounds=0;
    time start_time=0;
    reg [95:0] bank=0;
    reg [7:0] saved_gate=0;
    reg [127:0] saved_gain=0;
    always @(posedge scan_start) begin rounds=rounds+1; start_time=$time; end
    always @(posedge controls_valid) frames=frames+1;
    always @(posedge timeout) begin
        errors=errors+1;
        #1;
        if(gate!==saved_gate || key_gain!==saved_gain || controls_valid ||
           timeout_count!==errors || frame_valid || !spi_abort) $fatal(1,"Fault changed held controls");
    end
    task reply(input integer ch);
        begin
            @(posedge spi_start);
            if(spi_channel!==ch[2:0]) $fatal(1,"Wrong request channel");
            @(negedge clk); spi_busy=1;
            repeat(5) @(negedge clk);
            spi_data=bank[12*ch+:12]; spi_busy=0; spi_valid=1;
            @(negedge clk); spi_valid=0;
        end
    endtask
    task good(input [7:0] expected_gate);
        begin
            @(posedge scan_start);
            for(integer c=0;c<8;c=c+1) reply(c);
            @(posedge controls_valid); #1;
            if(gate!==expected_gate || control_raw_frame!==bank) $fatal(1,"Confirmation after fault gate=%h expected=%h",gate,expected_gate);
            saved_gate=gate; saved_gain=key_gain;
        end
    endtask
    task abort_done;
        begin
            @(negedge clk); spi_busy=0; spi_valid=0;
            repeat(25) @(negedge clk);
            if(controls_valid || gate!==saved_gate || key_gain!==saved_gain) $fatal(1,"Late fault publication");
        end
    endtask
    initial begin
        $dumpfile("handoff.vcd");
        $dumpvars(0,rst_n,spi_start,spi_channel,spi_busy,spi_valid,spi_data,spi_abort,
            raw_frame,frame_valid,scan_start,timeout,timeout_count,gate,key_gain,controls_valid);
        repeat(5) @(negedge clk); rst_n=1; bank={8{12'd3000}};
        good(8'h00); // First press confirmation.
        @(posedge scan_start);
        for(k=0;k<3;k=k+1) reply(k);
        @(posedge spi_start); @(negedge clk); spi_busy=1;
        @(posedge timeout); abort_done();
        good(8'h00); // Missing round breaks consecutive confirmations.
        good(8'h0f);
        bank=0; good(8'h0f); // First release confirmation.
        @(posedge scan_start);
        for(k=0;k<7;k=k+1) reply(k);
        @(posedge spi_start); @(negedge clk); spi_busy=1;
        #(start_time+1000000-$time-10);
        spi_data=0; spi_busy=0; spi_valid=1; // CH7 exactly at deadline loses.
        @(posedge timeout); abort_done();
        good(8'h0f);
        good(8'h00);
        if(key_gain!==0 || frames!=6 || errors!=2 || rounds!=8) $fatal(1,"Fault final counts");
        $display("PASS ALL fault_handoff frames=6 timeouts=2 missing_CH3=1 deadline_CH7=1 confirmations_cleared=2");
        $finish;
    end
    initial begin #12000000; $fatal(1,"Fault handoff timeout"); end
endmodule
`default_nettype wire
