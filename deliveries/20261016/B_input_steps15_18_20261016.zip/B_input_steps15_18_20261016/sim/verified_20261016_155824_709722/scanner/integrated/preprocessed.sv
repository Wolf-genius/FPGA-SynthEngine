`timescale 1ns/1ps
`default_nettype none

// One MCP3208 single-ended conversion. All registers use the 50 MHz clk.
// start/channel must already be synchronous to clk. Pulse start for one cycle;
// it is accepted only in IDLE. Busy-time pulses are discarded, not queued.
// A start held into the next IDLE is a new request (not an edge detector).
// channel is captured as part of the command when the request is accepted.
// After reset an early request is accepted, but CS waits for a 2 us high guard.
// data changes only on reset or valid; valid lasts one clk cycle, busy is then 0.
// This module does not schedule scans or publish an eight-channel control frame.
module adc_spi (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [2:0]  channel,
    input  wire        miso,
    output reg         cs_n,
    output reg         sclk,
    output reg         mosi,
    output reg         busy,
    output reg  [11:0] data,
    output reg         valid
);
    // Fixed project timing: 50 MHz / (2*50) = 500 kHz.
    // Separate counters/limits keep the 2 us gap from changing SPI frequency.
    localparam integer HALF_CYCLES = 50;
    localparam integer CS_HIGH_CYCLES = 100;
    localparam [2:0] IDLE = 3'd0, SHIFT = 3'd1,
                     HOLD = 3'd2, GAP = 3'd3, WAIT_HIGH = 3'd4;

    reg [2:0] state;
    reg [6:0] count; // Must represent 99 for the 100-cycle CS-high gap.
    reg [4:0] bit_index;
    reg [23:0] tx_shift;
    reg [11:0] rx_shift;
    reg miso_meta;
    reg miso_sync;

    // DOUT changes after the external falling SCLK edge. At 500 kHz the
    // 1 us half-cycle allows the modeled 200 ns DOUT delay plus this pipeline.
    // RTL simulation does not prove metastability MTBF or physical IO timing.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            miso_meta <= 1'b0;
            miso_sync <= 1'b0;
        end else begin
            miso_meta <= miso;
            miso_sync <= miso_meta;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            count <= 7'd0;
            bit_index <= 5'd0;
            tx_shift <= 24'd0;
            rx_shift <= 12'd0;
            cs_n <= 1'b1;
            sclk <= 1'b0;
            mosi <= 1'b0;
            busy <= 1'b0;
            data <= 12'd0;
            valid <= 1'b0;
        end else begin
            valid <= 1'b0;
            case (state)
                IDLE: begin
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    // Saturating reset-recovery guard. Normal GAP completion
                    // preloads 100, so it does not add a second normal gap.
                    // 101 observed edges span >=100 full periods even when
                    // reset deassertion is asynchronous to clk.
                    if (count < CS_HIGH_CYCLES)
                        count <= count + 7'd1;
                    if (start) begin
                        // [23:19]=0, [18]=Start, [17]=single-ended,
                        // [16:14]=channel. CH0=060000, CH1=064000.
                        tx_shift <= {5'b00000, 2'b11, channel, 14'd0};
                        rx_shift <= 12'd0;
                        bit_index <= 5'd0;
                        busy <= 1'b1;
                        if (count == CS_HIGH_CYCLES) begin
                            count <= 7'd0;
                            cs_n <= 1'b0;
                            state <= SHIFT;
                        end else begin
                            state <= WAIT_HIGH;
                        end
                    end
                end
                WAIT_HIGH: begin
                    if (count == CS_HIGH_CYCLES) begin
                        count <= 7'd0;
                        cs_n <= 1'b0;
                        state <= SHIFT;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                SHIFT: begin
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        if (!sclk) begin
                            sclk <= 1'b1;
                            // Zero-based 12..23 = rising edges 13..24.
                            // Ignore the unknown prefix and edge-12 null.
                            if (bit_index >= 5'd12)
                                rx_shift <= {rx_shift[10:0], miso_sync};
                        end else begin
                            sclk <= 1'b0;
                            if (bit_index == 5'd23) begin
                                state <= HOLD;
                            end else begin
                                mosi <= tx_shift[22];
                                tx_shift <= {tx_shift[22:0], 1'b0};
                                bit_index <= bit_index + 5'd1;
                            end
                        end
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                HOLD: begin
                    // Keep CS low for 1 us after the final falling SCLK edge.
                    if (count == HALF_CYCLES - 1) begin
                        count <= 7'd0;
                        cs_n <= 1'b1;
                        mosi <= 1'b0;
                        state <= GAP;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                GAP: begin
                    // Remain busy until CS has been high for 2 us.
                    // The earliest next acceptance adds another clk cycle.
                    if (count == CS_HIGH_CYCLES - 1) begin
                        count <= 7'd100;
                        data <= rx_shift; // B0 was captured earlier in SHIFT.
                        valid <= 1'b1;
                        busy <= 1'b0;
                        state <= IDLE;
                    end else begin
                        count <= count + 7'd1;
                    end
                end
                default: begin
                    state <= IDLE;
                    count <= 7'd0;
                    cs_n <= 1'b1;
                    sclk <= 1'b0;
                    mosi <= 1'b0;
                    busy <= 1'b0;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Eight single-ended ADC reads per 1 ms. 50 MHz synchronous SPI-side handshake.
// Separate controller ports allow a stalled SPI handshake to be tested without
// forcing DUT internals. MISO alone cannot stall the existing fixed-length SPI.
module adc_scan_controller (
    input wire clk,
    input wire rst_n,
    input wire spi_busy,
    input wire spi_valid,
    input wire [11:0] spi_data,
    output reg spi_start,
    output reg [2:0] spi_channel,
    output reg spi_abort,
    output reg [95:0] raw_frame,
    output reg frame_valid,
    output reg scan_start,
    output reg scan_busy,
    output reg timeout,
    output reg [31:0] timeout_count
);
    localparam [1:0] IDLE = 2'd0, ISSUE = 2'd1, WAIT_RESULT = 2'd2;
    localparam [15:0] PERIOD_LAST = 16'd49999;
    reg [1:0] state;
    reg [15:0] period_count;
    reg [95:0] shadow_frame;
    wire period_tick = (period_count == PERIOD_LAST);

    // First attempt is on the 50,000th active clock after reset release.
    // The periodic grid never shifts with completion time or a timeout.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) period_count <= 16'd0;
        else if (period_tick) period_count <= 16'd0;
        else period_count <= period_count + 16'd1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            shadow_frame <= 96'd0;
            raw_frame <= 96'd0;
            spi_start <= 1'b0;
            spi_channel <= 3'd0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            scan_busy <= 1'b0;
            timeout <= 1'b0;
            timeout_count <= 32'd0;
        end else begin
            spi_start <= 1'b0;
            spi_abort <= 1'b0;
            frame_valid <= 1'b0;
            scan_start <= 1'b0;
            timeout <= 1'b0;
            // Deadline wins over a coincident result, including CH7.
            // A failed round is discarded; do not start another on this tick.
            // Retry CH0 at the following 1 ms tick after the abort pulse.
            if (period_tick && state != IDLE) begin
                state <= IDLE;
                scan_busy <= 1'b0;
                shadow_frame <= 96'd0;
                spi_channel <= 3'd0;
                spi_abort <= 1'b1;
                timeout <= 1'b1;
                if (timeout_count != 32'hffffffff)
                    timeout_count <= timeout_count + 32'd1;
            end else begin
                case (state)
                    IDLE: begin
                        if (period_tick) begin
                            scan_start <= 1'b1;
                            scan_busy <= 1'b1;
                            shadow_frame <= 96'd0;
                            spi_channel <= 3'd0;
                            state <= ISSUE;
                        end
                    end
                    ISSUE: begin
                        if (!spi_busy) begin
                            spi_start <= 1'b1;
                            state <= WAIT_RESULT;
                        end
                    end
                    WAIT_RESULT: begin
                        if (spi_valid) begin
                            if (spi_channel == 3'd7) begin
                                // Include the CURRENT CH7 result; do not read
                                // an old shadow[95:84] on the same NBA edge.
                                raw_frame <= {spi_data, shadow_frame[83:0]};
                                frame_valid <= 1'b1;
                                scan_busy <= 1'b0;
                                state <= IDLE;
                            end else begin
                                shadow_frame[12*spi_channel +: 12] <= spi_data;
                                spi_channel <= spi_channel + 3'd1;
                                state <= ISSUE;
                            end
                        end
                    end
                    default: begin
                        state <= IDLE;
                        scan_busy <= 1'b0;
                        shadow_frame <= 96'd0;
                        spi_abort <= 1'b1;
                    end
                endcase
            end
        end
    end
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
// Synthesizable module wrapper, not a board top (no pin/LED/clock constraints).
// raw_frame[11:0]=CH0 ... raw_frame[95:84]=CH7, all 12-bit unsigned.
// frame_valid/scan_start/timeout are single clk pulses. raw_frame holds between
// publications, including timeouts; global reset clears it and all diagnostics.
// Raw ADC frames require later calibration/mapping before gate/key_gain use.
module adc_scan (
    input wire clk,
    input wire rst_n,
    input wire miso,
    output wire cs_n,
    output wire sclk,
    output wire mosi,
    output wire [95:0] raw_frame,
    output wire frame_valid,
    output wire scan_start,
    output wire scan_busy,
    output wire timeout,
    output wire [31:0] timeout_count
);
    wire spi_start, spi_busy, spi_valid, spi_abort;
    wire [2:0] spi_channel;
    wire [11:0] spi_data;
    // Controller abort resets only the SPI engine. Keep the last published raw
    // frame and timeout count. System top is responsible for global reset release.
    wire spi_rst_n = rst_n & ~spi_abort;
    adc_spi spi (.clk(clk), .rst_n(spi_rst_n), .start(spi_start),
        .channel(spi_channel), .miso(miso), .cs_n(cs_n), .sclk(sclk),
        .mosi(mosi), .busy(spi_busy), .data(spi_data), .valid(spi_valid));
    adc_scan_controller controller (.clk(clk), .rst_n(rst_n),
        .spi_busy(spi_busy), .spi_valid(spi_valid), .spi_data(spi_data),
        .spi_start(spi_start), .spi_channel(spi_channel), .spi_abort(spi_abort),
        .raw_frame(raw_frame), .frame_valid(frame_valid), .scan_start(scan_start),
        .scan_busy(scan_busy), .timeout(timeout), .timeout_count(timeout_count));
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none

// Behavioral digital protocol model, not an analog converter model.
// Only the external SPI pins select the channel. No DUT hierarchy is used.
// Search for Start, then decode SGL and D2..D0 relative to that Start.
module mcp3208_model (
    input wire rst_n,
    input wire cs_n,
    input wire sclk,
    input wire mosi,
    input wire [95:0] channel_values,
    input integer dout_delay_ns,
    output reg miso,
    output reg [2:0] decoded_channel,
    output reg [11:0] selected_value,
    output reg [23:0] command_seen,
    output integer rise_count,
    output integer start_edge
);
    reg started;
    integer after_start;
    integer frame_id = 0;
    integer scheduled_frame;
    reg scheduled_bit;

    initial miso = 1'bx;

    always @(negedge cs_n) begin
        frame_id = frame_id + 1;
        rise_count = 0;
        start_edge = 0;
        after_start = 0;
        started = 0;
        decoded_channel = 0;
        selected_value = 12'hxxx;
        command_seen = 0;
        miso = 1'bx;
    end

    always @(posedge sclk) begin
        if (rst_n && !cs_n) begin
            rise_count = rise_count + 1;
            command_seen = {command_seen[22:0], mosi};
            if (!started) begin
                if (mosi === 1'b1) begin
                    started = 1;
                    start_edge = rise_count;
                    after_start = 0;
                end else if (mosi !== 1'b0)
                    $fatal(1, "MODEL unknown DIN before Start");
            end else begin
                after_start = after_start + 1;
                case (after_start)
                    1: if (mosi !== 1'b1)
                           $fatal(1, "MODEL expected single-ended SGL=1");
                    2: decoded_channel[2] = mosi;
                    3: decoded_channel[1] = mosi;
                    4: begin
                        decoded_channel[0] = mosi;
                        if (^decoded_channel === 1'bx)
                            $fatal(1, "MODEL unknown channel bits");
                        selected_value = channel_values[12*decoded_channel +: 12];
                    end
                endcase
            end
        end
    end

    always @(negedge sclk) begin
        if (rst_n && !cs_n) begin
            scheduled_frame = frame_id;
            if (started && after_start == 5)
                scheduled_bit = 1'b0; // Null, received on the next rising edge.
            else if (started && after_start >= 6 && after_start <= 17)
                scheduled_bit = selected_value[17-after_start];
            else
                scheduled_bit = 1'bx;
            #(dout_delay_ns);
            if (rst_n && !cs_n && frame_id == scheduled_frame)
                miso = scheduled_bit;
        end
    end

    always @(posedge cs_n or negedge rst_n)
        miso = 1'bx;
endmodule
`default_nettype wire
`timescale 1ns/1ps
`default_nettype none
module tb_adc_scan;
    reg clk=0, rst_n=0;
    always #10 clk=~clk;
    wire cs_n,sclk,mosi,miso,frame_valid,scan_start,scan_busy,timeout;
    wire [95:0] raw_frame;
    wire [31:0] timeout_count;
    reg [95:0] channel_values=0;
    integer dout_delay_ns=200;
    wire [2:0] decoded_channel;
    wire [11:0] selected_value;
    wire [23:0] command_seen;
    wire signed [31:0] model_rises,model_start_edge;
    adc_scan dut(.*);
    mcp3208_model adc(.rst_n(rst_n),.cs_n(cs_n),.sclk(sclk),.mosi(mosi),
        .channel_values(channel_values),.dout_delay_ns(dout_delay_ns),.miso(miso),
        .decoded_channel(decoded_channel),.selected_value(selected_value),
        .command_seen(command_seen),.rise_count(model_rises),.start_edge(model_start_edge));

    integer rounds=0,frames=0,transactions=0,aborted=0,completed=0;
    integer ch=0,rises=0,falls=0,atomic_checks=0,epoch=0;
    integer frame_log,transaction_log;
    reg active=0,round_active=0;
    reg [95:0] expected_frame=0,old_frame=0;
    reg [23:0] tx=0;
    reg [11:0] rx=0;
    time round_start,last_round=0,cs_start,last_cs_end=0,last_edge=0,last_fall=0;
    time frame_pulse=0,scan_pulse=0;
    reg [95:0] previous_publication=0;
    integer active_clock_count=0;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) active_clock_count=0;
        else begin
            active_clock_count=active_clock_count+1;
            #1;
            if (scan_start && active_clock_count%50000!=0)
                $fatal(1,"Scan start not on 50,000-clock grid");
        end
    end

    always @(posedge scan_start) begin
        if (!rst_n || round_active || !scan_busy) $fatal(1,"Overlapping round");
        if (last_round && $time-last_round!=1000000) $fatal(1,"Scan period not 1ms");
        rounds=rounds+1; ch=0; completed=0; round_active=1;
        expected_frame=channel_values; old_frame=raw_frame;
        round_start=$time; last_round=$time; scan_pulse=$time;
        $display("SCAN round=%0d epoch=%0d start_ns=%0d clock_count=%0d expected=%024h",rounds,epoch,$time,active_clock_count,expected_frame);
    end
    always @(negedge scan_start)
        if (rst_n && scan_pulse && $time-scan_pulse!=20) $fatal(1,"scan_start width");

    always @(negedge cs_n) begin
        if (rst_n) begin
            if (!round_active || ch>7 || active) $fatal(1,"Unexpected SPI request");
            if (last_cs_end && $time-last_cs_end<2000) $fatal(1,"CS gap <2us");
            active=1; rises=0; falls=0; tx=0; rx=0; last_edge=0; cs_start=$time;
            if (ch==4) begin
                if (raw_frame!==old_frame) $fatal(1,"Partial frame visible at CH4");
                atomic_checks=atomic_checks+1;
                $display("PASS atomic_CH4 round=%0d old_frame=%024h",rounds,raw_frame);
            end
        end
    end
    always @(sclk) begin
        if (rst_n && sclk && cs_n) $fatal(1,"SCLK outside CS");
        if (rst_n && active) begin
            if (last_edge && $time-last_edge!=1000) $fatal(1,"SPI half-cycle");
            last_edge=$time;
            if (sclk) begin
                rises=rises+1; tx={tx[22:0],mosi};
                if (rises==1 && $time-cs_start!=1000) $fatal(1,"CS setup");
                if (rises<=11 && miso!==1'bx) $fatal(1,"Unknown prefix");
                if (rises==12 && miso!==0) $fatal(1,"Null");
                if (rises>=13) rx={rx[10:0],miso};
            end else begin falls=falls+1; last_fall=$time; end
        end
    end
    always @(posedge cs_n) begin
        if (active) begin
            transactions=transactions+1;
            if (rst_n) begin
                if (rises!=24 || falls!=24 || sclk || $time-last_fall!=1000)
                    $fatal(1,"Incomplete SPI transaction");
                if (tx!==(24'h060000 | (ch<<14)) || decoded_channel!==ch[2:0] || model_start_edge!=6)
                    $fatal(1,"Channel/command mismatch ch=%0d tx=%h",ch,tx);
                if (rx!==expected_frame[12*ch+:12] || selected_value!==rx)
                    $fatal(1,"Channel payload mismatch");
                $fdisplay(transaction_log,"%0d,%0d,%0d,normal,%0d,%0d,%0d,%0d,%06h,%03h",
                    transactions,rounds,ch,cs_start,$time,rises,falls,tx,rx);
                completed=completed+1; ch=ch+1;
            end else begin
                aborted=aborted+1;
                $fdisplay(transaction_log,"%0d,%0d,%0d,reset_abort,%0d,%0d,%0d,%0d,%06h,---",
                    transactions,rounds,ch,cs_start,$time,rises,falls,tx);
            end
            last_cs_end=$time; active=0;
        end
    end
    always @(raw_frame) begin
        #1;
        if (rst_n && !frame_valid) $fatal(1,"raw_frame changed without valid");
    end
    always @(posedge frame_valid) begin
        frame_pulse=$time;
        if (!rst_n || !round_active || scan_busy || completed!=8 || raw_frame!==expected_frame)
            $fatal(1,"Frame publication failed got=%024h expected=%024h",raw_frame,expected_frame);
        if ($time-round_start>=1000000) $fatal(1,"Scan exceeded deadline");
        frames=frames+1; round_active=0; previous_publication=raw_frame;
        $fdisplay(frame_log,"%0d,%0d,%0d,%0d,%0d,%0d,%024h,%024h",frames,rounds,epoch,
            round_start,$time,$time-round_start,raw_frame,expected_frame);
        $display("PASS frame=%0d round=%0d latency_ns=%0d raw=%024h",frames,rounds,$time-round_start,raw_frame);
    end
    always @(negedge frame_valid)
        if (rst_n && frame_pulse && $time-frame_pulse!=20) $fatal(1,"frame_valid width");
    always @(posedge timeout) $fatal(1,"Unexpected normal-link timeout");
    always @(negedge rst_n) begin
        #2;
        if (raw_frame!==0 || frame_valid || scan_busy || timeout || timeout_count!==0 || !cs_n || sclk)
            $fatal(1,"Reset did not clear partial frame/outputs");
        round_active=0; last_round=0; epoch=epoch+1;
        $display("PASS reset_discard_partial frame_count=%0d",frames);
    end
    task set_bank(input integer base);
        integer k;
        begin for(k=0;k<8;k=k+1) channel_values[12*k+:12]=base+100*k; end
    endtask
    initial begin
        frame_log=$fopen("frames.csv","w"); transaction_log=$fopen("transactions.csv","w");
        if (!frame_log || !transaction_log) $fatal(1,"Cannot open evidence");
        $fdisplay(frame_log,"frame,round,epoch,start_ns,publish_ns,duration_ns,raw_frame,expected_frame");
        $fdisplay(transaction_log,"transaction,round,channel,status,start_ns,end_ns,rises,falls,command,payload");
        $dumpfile("scan.vcd");
        $dumpvars(0,rst_n,cs_n,sclk,mosi,miso,raw_frame,frame_valid,scan_start,scan_busy,timeout,timeout_count,channel_values);
        channel_values={12'h001,12'h800,12'hAAA,12'h555,12'hFFF,12'hABC,12'h001,12'h000};
        repeat(5) @(negedge clk); rst_n=1;
        wait(frames==1); @(negedge clk); set_bank(100);
        wait(frames==3); // Two identical input frames must still each publish.
        @(negedge clk); set_bank(1100);
        wait(frames==4);
        wait(active && ch==4 && rises==7); #17; rst_n=0;
        #20; rst_n=1; set_bank(2100);
        wait(frames==6);
        repeat(4) @(negedge clk);
        if (rounds!=7 || transactions!=53 || aborted!=1 || atomic_checks!=7 || timeout_count!==0)
            $fatal(1,"Final integrated counts wrong");
        $display("PASS ALL integrated frames=6 rounds=7 transactions=53 aborted=1 atomic_CH4=7 timeout_count=0");
        $fclose(frame_log); $fclose(transaction_log); $finish;
    end
    initial begin #12000000; $fatal(1,"Integrated test timeout"); end
endmodule
`default_nettype wire
