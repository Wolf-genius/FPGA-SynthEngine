open_project {D:/gowin1/voice/pressure_keys_sim/synthesis/verified_20261016_155352_241641/keys8/pressure_input.gprj}
set_option -top_module synthesis_top
set_option -verilog_std sysv2017
run syn
