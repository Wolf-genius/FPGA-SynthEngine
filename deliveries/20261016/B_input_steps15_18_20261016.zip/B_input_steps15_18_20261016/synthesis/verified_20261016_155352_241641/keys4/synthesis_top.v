module synthesis_top(input wire clk,rst_n,miso,
output wire cs_n,sclk,mosi,output wire [7:0] gate,
output wire [127:0] key_gain,output wire controls_valid,
output wire [95:0] raw_frame,control_raw_frame,
output wire frame_valid,scan_start,scan_busy,timeout,
output wire [31:0] timeout_count);
pressure_keys_input #(.ACTIVE_KEYS(4)) dut(.*);
endmodule
