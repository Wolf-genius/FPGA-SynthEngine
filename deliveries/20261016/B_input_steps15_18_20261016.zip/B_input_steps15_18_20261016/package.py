"""Package current validated B delivery; preserve historical attempts locally."""
from pathlib import Path
import argparse, hashlib, json, zipfile

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--output',required=True)
args=p.parse_args()
destination=Path(args.output).resolve()
assert not destination.exists(),'Refusing to replace an existing delivery'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def latest(folder,status):
    for f in sorted((root/folder).glob('verified_*/manifest.json'),reverse=True):
        m=json.loads(f.read_text(encoding='utf-8'))
        if m['status']==status:
            assert all(sha(root/k)==v for k,v in m['input_sha256'].items()),'Evidence does not bind current sources'
            return f.parent,m
    raise RuntimeError('No validated evidence in '+folder)
sim,sm=latest('sim','PASS'); syn,ym=latest('synthesis','PASS_SYNTHESIS_ONLY')
files=[p for p in root.iterdir() if p.is_file()]
for folder in ['src','tb','examples','docs']:
    files += [p for p in (root/folder).rglob('*') if p.is_file()]
files += list((root/'sim').glob('*.py')) + list((root/'synthesis').glob('*.py'))
files += [p for d in [sim,syn] for p in d.rglob('*') if p.is_file()]
files=sorted(set(files))
hashes={p.relative_to(root).as_posix():sha(p) for p in files}
metadata=dict(scope='B 10/15-18 code; no ADSR/audio-core or board certification',
    sim_evidence=sim.relative_to(root).as_posix(),synthesis_evidence=syn.relative_to(root).as_posix(),
    file_sha256=hashes)
prefix='B_input_steps15_18_20261016'
destination.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in files: z.write(path,prefix+'/'+path.relative_to(root).as_posix())
    z.writestr(prefix+'/DELIVERY_MANIFEST.json',json.dumps(metadata,indent=2)+'\n')
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None,'ZIP CRC error'
    for name,digest in hashes.items():
        assert hashlib.sha256(z.read(prefix+'/'+name)).hexdigest()==digest,name
report=dict(status='PASS',zip_sha256=sha(destination),zip_bytes=destination.stat().st_size,
    verified_files=len(hashes),sim_evidence=metadata['sim_evidence'],
    synthesis_evidence=metadata['synthesis_evidence'],crc_and_all_file_hashes=True)
destination.with_suffix('.verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
