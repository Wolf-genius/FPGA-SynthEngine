# B：10/15～18 输入代码交付

实际开发/验证：2026-10-16（Asia/Shanghai）。本目录独立新增，原成功一键工程、ADC源码和历史证据保持原字节。正式入口是 `src/pressure_keys_input.v`，默认前四键启用。完整来源见 `SOURCE_ORIGINS.json`。

本次完成B的代码部分：八路1ms扫描、逐键滞回/两轮确认/映射/Q16.8平滑、完整八键格式控制帧、真假输入示例、四键独立性与ADSR输入场景。ADSR/voice/mixer是队长模块，本包没有实现或验证声音包络。实测校准、四路实际电路、机械布局、四键实物与整机验收仍待完成。

## 直接交给队长和A什么

1. 把本目录整体交给A，综合只加入 `rtl.f` 中六个RTL，实例化 `pressure_keys_input`。同名 `adc_spi` / `adc_scan` / `adc_scan_controller` 只能各编译一份，不能与旧副本重复加入。
2. `gate[7:0]`、`key_gain[127:0]`、`controls_valid` 接队长核心。CH0为最低位/最低16位，默认CH4～7输出零；参数 `ACTIVE_KEYS=1/4/8` 分阶段使用，不改变端口。
3. 队长可先使用 `examples/fake_four_key_controls.v`，无需ADC；接收规则参考 `examples/control_frame_receiver.v`。假源与真源只能明确选择一个。
4. 依照 [交接说明](docs/交接给队长和A.md) 接线及接收；依照 [验证记录](docs/验证记录.md) 核对测试版本。不要将本包直接作为原成功版FS下载。

## 端口与复位

所有内部控制同50MHz主时钟域；rst_n异步低有效，板级顶层由A统一同步释放。MISO在SPI驱动内部经过两级同步，其余多位帧不得逐位跨时钟同步。

| 端口 | 方向/位宽/符号 | 行为 |
|---|---|---|
| clk/rst_n | 输入，各1位 | 50MHz / 异步低有效复位 |
| miso | 输入1位 | MCP3208 DOUT，正式方向始终输入 |
| cs_n/sclk/mosi | 输出，各1位 | 现有Mode0/500kHz/24完整周期；复位1/0/0 |
| gate | 输出8位 | 持续按住状态，允许多位1，复位零 |
| key_gain | 输出128位无符号 | CHi在[16*i+:16]，松开及禁用路零，复位零 |
| controls_valid | 输出1位 | 完整gate/gain及control_raw_frame同沿发布；正常每1ms一拍、20ns宽 |
| raw_frame/frame_valid | 输出96位无符号/1位 | 扫完CH7后完整原始帧/一拍有效；CH0最低12位 |
| control_raw_frame | 输出96位无符号 | 与最新控制帧对应的原始快照，便于GAO校准；复位零 |
| scan_start/scan_busy | 输出，各1位 | 启动一拍 / 扫描期间为1 |
| timeout/timeout_count | 输出1位/32位无符号 | 超时一拍 / 饱和计数；全局复位清零 |

`pressure_frame_controls` 可单独接已有完整原始帧：每个frame_valid高电平采样沿接受一整帧，无busy/ready，可连续每拍接受。正常扫描上游每1ms只给一拍；连续有效时每个沿都是一帧，不能仅按valid上升沿接收。frame_cancel为同步取消通知，优先于frame_valid，真实封装连接扫描timeout。

## 算法、默认占位参数

每键独立TON/TOFF/RAW_MIN/RAW_MAX/MIN_GAIN，默认256/128/128/3840/4096，沿用现有CH0开发值，**不是四片传感器的实测校准**。参数为编译期常量；每片测量后分别填写，修改后重新仿真和构建。参数打包名为TON_PACK、TOFF_PACK、RAW_MIN_PACK、RAW_MAX_PACK（各96位），MIN_GAIN_PACK（128位），均CH0最低。

- 松开→按下需连续两轮raw>=TON；按住→松开需连续两轮raw<=TOFF。滞回区保持状态，不满足当前确认条件的有效帧清计数。没有新帧的主时钟不计数。
- 目标力度=`MIN_GAIN + floor((clamp(raw)-RAW_MIN)*(65535-MIN_GAIN)/(RAW_MAX-RAW_MIN))`，上下端限幅。约束TON>TOFF、RAW_MAX>RAW_MIN、MIN_GAIN>0。
- 平滑按旧值+(目标-旧值)/4，内部Q16.8，25位有符号差，除法向零截断，输出四舍五入到整数；按住至少MIN_GAIN。首次按下从MIN_GAIN开始平滑；松开立即输出零、清该键平滑，重按重新开始。负阶跃必须正确下降。
- 映射复用一键工程的登记乘积及16级逐位除法，避免原组合除法的长路径；本次新工程的布局布线/50MHz时序仍须由A验证。
- 扫描超时：保持现有截止优先、丢半帧、保留旧raw、局部复位SPI、再下一周期从CH0重试。控制层保留上一完整gate/gain、清确认计数并取消在途帧；恢复后重新要求连续两轮。超时不强制松开，也不是物理ADC断线检测。

## 测得的数字时序

以完整原始帧在沿T发布为起点：压力处理在T+1沿接受，在T+20沿发布新控制（400ns），消费者在T+21沿接收。单独处理模块接受沿E到输出E+19为380ns。每轮scan_start到raw发布408.48us，到controls发布408.88us；完整帧间隔1ms。全局复位清所有输出和在途帧。

核心同沿接收controls_valid和sample_ce时，当前音频采样使用此前锁存的控制，下一采样使用新控制；本包参考接收器与逐拍测试覆盖。松开帧gate/gain同时归零，**核心必须冻结松开前力度并完成Release**。本包不会替核心保持gate或伪造非零释放力度。

上述仅数字仿真时序；两轮确认还受阈值到达扫描相位影响，不能据此宣称整机总延迟≤10ms或实物ADSR通过。

## 重跑

在本目录执行，或传脚本绝对路径（要求Python3.9+）：

```powershell
python sim/run_all.py --iverilog D:/iverilog/bin/iverilog.exe --vvp D:/iverilog/bin/vvp.exe
python synthesis/run_synthesis.py --gw-sh C:/Gowin/Gowin_V1.9.12.03_x64/IDE/bin/gw_sh.exe
```

本机Python可使用 `C:/Users/Copperfield/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`。每次新建证据目录，保存版本、命令、退出码、完整日志、波形、向量/CSV和哈希。Icarus外层正常编译仍以0xC0000005退出；失败探测产物不执行，正式测试采用同安装预处理器及显式ivl配置分阶段编译。Gowin脚本只做四/八键输入模块综合，不生成可下载FS，不验证物理时序。

## 现场还需做

填 `docs/校准记录.csv` 和 `docs/四键现场验收.csv`，由B逐片实测，A接入统一top/工程并重新构建，队长接四个独立ADSR声部。完整ADC数值验收、原成功版归档和总延迟测量要求保持，不因代码交付自动勾选10/15～18整日完成。
